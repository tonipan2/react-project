package com.example.graduate.service;

import com.example.graduate.dto.ApplicationDTO;
import com.example.graduate.model.Application;
import com.example.graduate.model.Student;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.User;
import com.example.graduate.repository.*;
import com.example.graduate.service.ApplicationService;
import com.example.graduate.service.StudentService;
import com.example.graduate.service.TeacherService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import jakarta.persistence.EntityNotFoundException;

import java.util.HashSet;
import java.util.Optional;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ApplicationServiceTest {

    @Mock
    private ApplicationRepository applicationRepo;

    @Mock
    private StudentRepository studentRepo;

    @Mock
    private TeacherRepository teacherRepo;

    @Mock
    private StudentService studentService;

    @Mock
    private TeacherService teacherService;

    @InjectMocks
    private ApplicationService applicationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void saveApplication_ShouldThrowExceptionWhenStudentNotFound() {
        ApplicationDTO applicationDTO = new ApplicationDTO();
        applicationDTO.setStudentId(1L);
        applicationDTO.setTeacherId(2L);

        when(studentRepo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> applicationService.saveApplication(applicationDTO));
        verify(applicationRepo, never()).save(any());
    }

    @Test
    void updateApplicationById_ShouldUpdateSuccessfully() {
        long applicationId = 1L;

        ApplicationDTO updatedDTO = new ApplicationDTO();
        updatedDTO.setTheme("Updated Theme");
        updatedDTO.setAim("Updated Aim");

        Application existingApplication = new Application();
        existingApplication.setTheme("Old Theme");


        when(applicationRepo.findById(applicationId)).thenReturn(Optional.of(existingApplication));
        when(applicationRepo.save(existingApplication)).thenReturn(existingApplication);

        Application updatedApplication = applicationService.updateApplicationById(applicationId, updatedDTO);

        assertThat(updatedApplication.getTheme()).isEqualTo("Updated Theme");
        verify(applicationRepo, times(1)).save(existingApplication);
    }

    @Test
    void updateApplicationById_ShouldThrowExceptionWhenNotFound() {
        long applicationId = 999L;
        ApplicationDTO updatedDTO = new ApplicationDTO();

        when(applicationRepo.findById(applicationId)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> applicationService.updateApplicationById(applicationId, updatedDTO));
        verify(applicationRepo, never()).save(any());
    }

    @Test
    void deleteApplicationById_ShouldDeleteSuccessfully() {
        long applicationId = 1L;

        when(applicationRepo.existsById(applicationId)).thenReturn(true);

        applicationService.deleteApplicationById(applicationId);

        verify(applicationRepo, times(1)).deleteById(applicationId);
    }

    @Test
    void deleteApplicationById_ShouldThrowExceptionWhenNotFound() {
        long applicationId = 999L;

        when(applicationRepo.existsById(applicationId)).thenReturn(false);

        assertThrows(EntityNotFoundException.class, () -> applicationService.deleteApplicationById(applicationId));
        verify(applicationRepo, never()).deleteById(applicationId);
    }

    @Test
    void findApplicationById_ShouldReturnApplicationWhenExists() {
        long applicationId = 1L;
        Application application = new Application();
        application.setId(applicationId);

        when(applicationRepo.findById(applicationId)).thenReturn(Optional.of(application));

        Optional<Application> foundApplication = applicationService.findApplicationById(applicationId);

        assertThat(foundApplication.isPresent()).isTrue();
        assertThat(foundApplication.get().getId()).isEqualTo(applicationId);
        verify(applicationRepo, times(1)).findById(applicationId);
    }

    @Test
    void findApplicationById_ShouldReturnEmptyWhenNotFound() {
        long applicationId = 999L;

        when(applicationRepo.findById(applicationId)).thenReturn(Optional.empty());

        Optional<Application> foundApplication = applicationService.findApplicationById(applicationId);

        assertThat(foundApplication.isPresent()).isFalse();
    }

    @Test
    void findAllApplications_ShouldReturnAllApplications() {
        List<Application> applications = List.of(
                new Application(1L, "Research 1"),
                new Application(2L, "Research 2")
        );

        when(applicationRepo.findAll()).thenReturn(applications);

        List<Application> allApplications = applicationService.findAllApplications();

        assertThat(allApplications).hasSize(2);
        assertThat(allApplications.get(0).getTheme()).isEqualTo("Research 1");
        verify(applicationRepo, times(1)).findAll();
    }

    @Test
    void doesApplicationExist_ShouldReturnTrueWhenExists() {
        long applicationId = 1L;
        when(applicationRepo.existsById(applicationId)).thenReturn(true);

        boolean exists = applicationService.doesApplicationExist(applicationId);

        assertThat(exists).isTrue();
        verify(applicationRepo, times(1)).existsById(applicationId);
    }

    @Test
    void doesApplicationExist_ShouldReturnFalseWhenNotExists() {
        long applicationId = 999L;
        when(applicationRepo.existsById(applicationId)).thenReturn(false);

        boolean exists = applicationService.doesApplicationExist(applicationId);

        assertThat(exists).isFalse();
    }
}
