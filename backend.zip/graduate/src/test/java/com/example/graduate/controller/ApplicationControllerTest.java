package com.example.graduate.controller;

import com.example.graduate.GraduateApplication;
import com.example.graduate.dto.ApplicationDTO;
import com.example.graduate.model.Application;
import com.example.graduate.model.AcceptanceType;
import com.example.graduate.service.ApplicationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(classes = GraduateApplication.class)  // Explicitly provide the main application class
@AutoConfigureMockMvc  // Enable MockMvc for testing
class ApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;  // Automatically injected MockMvc

    @MockBean
    private ApplicationService applicationService;  // Mocked ApplicationService

    @Autowired
    private ObjectMapper objectMapper;  // ObjectMapper for serializing requests

    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testDeleteApplication() throws Exception {
        Mockito.doNothing().when(applicationService).deleteApplicationById(1L);

        mockMvc.perform(delete("/application/delete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("The Application has been deleted"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testAddApplication() throws Exception {
        // Create ApplicationDTO with id = 0L because it's a new object (it shouldn't have an ID)
        ApplicationDTO applicationDTO = new ApplicationDTO(0L, "Theme", "Aim", "Tasks", "Technologies", AcceptanceType.UNDEFINED, 1L, 1L);

        // Create Application with id = 1L to simulate a saved application (this is what we expect to be returned)
        Application savedApplication = new Application(1L, "Theme", "Aim", "Tasks", "Technologies", AcceptanceType.UNDEFINED, null, null);

        // Mock the saveApplication method to return the savedApplication
        Mockito.when(applicationService.saveApplication(any(ApplicationDTO.class))).thenReturn(savedApplication);

        // Perform the POST request
        mockMvc.perform(post("/application/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(applicationDTO)))
                .andExpect(status().isOk())  // Expect HTTP status 200
                .andExpect(jsonPath("$.id").value(1L))  // Expect the returned Application ID to be 1
                .andExpect(jsonPath("$.theme").value("Theme"))  // Check that the theme is set correctly
                .andExpect(jsonPath("$.aim").value("Aim"))  // Check that the aim is set correctly
                .andExpect(jsonPath("$.tasks").value("Tasks"))  // Check that the tasks are set correctly
                .andExpect(jsonPath("$.technologies").value("Technologies"));  // Check that the technologies are set correctly
    }



    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testPatchApplication() throws Exception {
        // Create ApplicationDTO with the updated values
        ApplicationDTO updatedDTO = new ApplicationDTO(1L, "Updated Theme", "Updated Aim", "Updated Tasks", "Updated Technologies", AcceptanceType.UNDEFINED, 1L, 1L);

        // Create the expected Application entity with id = 1L
        Application updatedApplication = new Application(1L, "Updated Theme", "Updated Aim", "Updated Tasks", "Updated Technologies", AcceptanceType.UNDEFINED, 1L, 1L);

        // Mock the service method to return the updatedApplication when called
        Mockito.when(applicationService.updateApplicationById(eq(1L), any(ApplicationDTO.class))).thenReturn(updatedApplication);

        // Perform the PATCH request
        mockMvc.perform(patch("/application/edit/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedDTO)))
                .andExpect(status().isOk())  // Expect HTTP status 200
                .andExpect(jsonPath("$.id").value(1L))  // Expect the returned Application ID to be 1
                .andExpect(jsonPath("$.theme").value("Updated Theme"))  // Check that the theme is updated
                .andExpect(jsonPath("$.aim").value("Updated Aim"))  // Check that the aim is updated
                .andExpect(jsonPath("$.tasks").value("Updated Tasks"))  // Check that the tasks are updated
                .andExpect(jsonPath("$.technologies").value("Updated Technologies"));  // Check that the technologies are updated
    }



    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testFetchAllApplications() throws Exception {
        Application application = new Application(1L, "Theme", "Aim", "Tasks", "Technologies", AcceptanceType.UNDEFINED, null, null);
        Mockito.when(applicationService.findAllApplications()).thenReturn(Collections.singletonList(application));

        mockMvc.perform(get("/application/fetch/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].theme").value("Theme"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testFetchApplicationById() throws Exception {
        Application application = new Application(1L, "Theme", "Aim", "Tasks", "Technologies", AcceptanceType.UNDEFINED, null, null);
        Mockito.when(applicationService.findApplicationById(1L)).thenReturn(Optional.of(application));

        mockMvc.perform(get("/application/fetch/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.theme").value("Theme"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")  // Mock a user with role USER
    void testFetchApplicationById_NotFound() throws Exception {
        Mockito.when(applicationService.findApplicationById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/application/fetch/1"))
                .andExpect(status().isNotFound());
    }
}
