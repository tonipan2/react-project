package com.example.graduate.service;
import com.example.graduate.dto.RoleDTO;
import com.example.graduate.model.Role;
import com.example.graduate.repository.RoleRepository;
import com.example.graduate.service.RoleService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class RoleServiceTest {

    @InjectMocks
    private RoleService roleService; // The service under test

    @Mock
    private RoleRepository roleRepository; // Mocked repository

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    // --------------------------------------------
    // 1. Test: Save Role
    // --------------------------------------------
    @Test
    void testSaveRole_Successful() {
        // Arrange
        RoleDTO roleDTO = new RoleDTO("ROLE_ADMIN");
        Role savedRole = new Role(1L, "ROLE_ADMIN");

        when(roleRepository.save(any(Role.class))).thenReturn(savedRole);

        // Act
        Role result = roleService.saveRole(roleDTO);

        // Assert
        assertNotNull(result);
        assertEquals("ROLE_ADMIN", result.getAuthority());
        verify(roleRepository, times(1)).save(any(Role.class));
    }

    // --------------------------------------------
    // 2. Test: Update Role - Success
    // --------------------------------------------
    @Test
    void testUpdateRoleById_SuccessfulUpdate() {
        // Arrange
        long roleId = 1L;
        Role existingRole = new Role(roleId, "ROLE_USER");
        RoleDTO updatedRoleDTO = new RoleDTO("ROLE_MANAGER");

        when(roleRepository.findById(roleId)).thenReturn(Optional.of(existingRole));
        when(roleRepository.save(any(Role.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Role updatedRole = roleService.updateRoleById(roleId, updatedRoleDTO);

        // Assert
        assertEquals("ROLE_MANAGER", updatedRole.getAuthority());
        verify(roleRepository, times(1)).findById(roleId);
        verify(roleRepository, times(1)).save(existingRole);
    }

    // --------------------------------------------
    // 3. Test: Update Role - Not Found
    // --------------------------------------------
    @Test
    void testUpdateRoleById_RoleNotFound() {
        // Arrange
        long roleId = 1L;
        RoleDTO updatedRoleDTO = new RoleDTO("ROLE_MANAGER");

        when(roleRepository.findById(roleId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> roleService.updateRoleById(roleId, updatedRoleDTO));
        assertEquals("Role not found with id: " + roleId, exception.getMessage());
        verify(roleRepository, times(1)).findById(roleId);
        verify(roleRepository, never()).save(any(Role.class));
    }

    // --------------------------------------------
    // 4. Test: Delete Role - Success
    // --------------------------------------------
    @Test
    void testDeleteRoleById_Successful() {
        // Arrange
        long roleId = 1L;
        when(roleRepository.existsById(roleId)).thenReturn(true);

        // Act
        roleService.deleteRoleById(roleId);

        // Assert
        verify(roleRepository, times(1)).deleteById(roleId);
    }

    // --------------------------------------------
    // 5. Test: Delete Role - Not Found
    // --------------------------------------------
    @Test
    void testDeleteRoleById_RoleNotFound() {
        // Arrange
        long roleId = 1L;
        when(roleRepository.existsById(roleId)).thenReturn(false);

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> roleService.deleteRoleById(roleId));
        assertEquals("Role not found with id: " + roleId, exception.getMessage());
        verify(roleRepository, never()).deleteById(roleId);
    }

    // --------------------------------------------
    // 6. Test: Find Role By ID - Success
    // --------------------------------------------
    @Test
    void testFindRoleById_Successful() {
        // Arrange
        long roleId = 1L;
        Role role = new Role(roleId, "ROLE_USER");
        when(roleRepository.findById(roleId)).thenReturn(Optional.of(role));

        // Act
        Role result = roleService.findRoleById(roleId);

        // Assert
        assertNotNull(result);
        assertEquals("ROLE_USER", result.getAuthority());
        verify(roleRepository, times(1)).findById(roleId);
    }

    // --------------------------------------------
    // 7. Test: Find Role By ID - Not Found
    // --------------------------------------------
    @Test
    void testFindRoleById_NotFound() {
        // Arrange
        long roleId = 1L;
        when(roleRepository.findById(roleId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> roleService.findRoleById(roleId));
        assertEquals("Role not found with id: " + roleId, exception.getMessage());
        verify(roleRepository, times(1)).findById(roleId);
    }

    // --------------------------------------------
    // 8. Test: Find All Roles
    // --------------------------------------------
    @Test
    void testFindAllRoles() {
        // Arrange
        List<Role> roles = List.of(new Role(1L, "ROLE_USER"), new Role(2L, "ROLE_ADMIN"));
        when(roleRepository.findAll()).thenReturn(roles);

        // Act
        List<Role> result = roleService.findAllRoles();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("ROLE_USER", result.get(0).getAuthority());
        assertEquals("ROLE_ADMIN", result.get(1).getAuthority());
        verify(roleRepository, times(1)).findAll();
    }

    // --------------------------------------------
    // 9. Test: Check if Role Exists
    // --------------------------------------------
    @Test
    void testDoesRoleExist() {
        // Arrange
        long roleId = 1L;
        when(roleRepository.existsById(roleId)).thenReturn(true);

        // Act
        boolean result = roleService.doesRoleExist(roleId);

        // Assert
        assertTrue(result);
        verify(roleRepository, times(1)).existsById(roleId);
    }

    @Test
    void testDoesRoleExist_NotExist() {
        // Arrange
        long roleId = 2L;
        when(roleRepository.existsById(roleId)).thenReturn(false);

        // Act
        boolean result = roleService.doesRoleExist(roleId);

        // Assert
        assertFalse(result);
        verify(roleRepository, times(1)).existsById(roleId);
    }
}
