package com.example.graduate.controller;

public class UserControllerTest {
}
