package com.example.graduate.repository;

import com.example.graduate.model.Application;
import com.example.graduate.model.AcceptanceType;
import com.example.graduate.model.Student;
import com.example.graduate.model.Teacher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
public class ApplicationRepositoryTest {

    @Autowired
    private ApplicationRepository applicationRepository;

    private Application application;

    @BeforeEach
    public void setUp() {
        // Create mock Student and Teacher
        Student student = new Student();
        student.setId(1L);
        Teacher teacher = new Teacher();
        teacher.setId(1L);

        // Create Application object
        application = new Application();
        application.setId(1L);
        application.setTheme("Sample Theme");
        application.setAim("Sample Aim");
        application.setTasks("Sample Tasks");
        application.setTechnologies("Sample Technologies");
        application.setAcceptanceType(AcceptanceType.UNDEFINED);
        application.setStudent(student);
        application.setTeacher(teacher);
    }

    @Test
    public void testExistsById_ShouldReturnTrue_WhenApplicationExists() {
        // Save the application to the repository
        applicationRepository.save(application);

        // Test if the application exists by ID
        boolean exists = applicationRepository.existsById(application.getId());
        assertTrue(exists, "Application should exist with the given ID");
    }

    @Test
    public void testExistsById_ShouldReturnFalse_WhenApplicationDoesNotExist() {
        // Test if the application exists by an ID that does not exist
        boolean exists = applicationRepository.existsById(999L);  // A non-existent ID
        assertFalse(exists, "Application should not exist with the given non-existent ID");
    }
}
