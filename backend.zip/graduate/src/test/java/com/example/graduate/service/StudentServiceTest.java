package com.example.graduate.service;

import com.example.graduate.dto.StudentDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.*;
import com.example.graduate.service.StudentService;
import com.example.graduate.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class StudentServiceTest {

    @InjectMocks
    private StudentService studentService; // The service under test

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @Mock
    private UserService userService;  // to prevent NullPointerException

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    // --------------------------------------------
    // 1. Test: Save Student - Successful
    // --------------------------------------------
    @Test
    void testSaveStudent_Successful() {
        // Arrange
        User user = new User();
        user.setId(1L);
        user.setAuthorities(Set.of(new Role(1L, "ROLE_STUDENT")));

        Department department = new Department();
        department.setId(1L);

        StudentDTO studentDTO = new StudentDTO(1L, "0", 0L, Set.of(1L));



        when(userService.findUserById(1L)).thenReturn(user);
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(studentRepository.save(any(Student.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Student savedStudent = studentService.saveStudent(studentDTO);

        // Assert
        assertNotNull(savedStudent);
        assertTrue(savedStudent.getFacultyNumber().matches("F\\d{6}"));  // Check format
        assertEquals(1, savedStudent.getDepartments().size());
        verify(studentRepository, times(1)).save(any(Student.class));
    }



    // --------------------------------------------
    // 2. Test: Save Student - User Not Found
    // --------------------------------------------

    @Test
    void testSaveStudent_UserNotFound() {
        // Arrange
        StudentDTO studentDTO = new StudentDTO(1L, "0", 0L, Set.of(1L));


        // Mock userService to throw EntityNotFoundException
        when(userService.findUserById(1L)).thenThrow(new EntityNotFoundException("User not found with id: 1"));

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> studentService.saveStudent(studentDTO));
        assertEquals("User not found with id: 1", exception.getMessage());
        verify(studentRepository, never()).save(any(Student.class));  // Ensure student is not saved
    }

    // --------------------------------------------
    // 3. Test: Save Student - Department Not Found
    // --------------------------------------------
    @Test
    void testSaveStudent_DepartmentNotFound() {
        // Arrange
        User user = new User();
        user.setId(1L);
        user.setAuthorities(Set.of(new Role(1L, "ROLE_STUDENT")));  // Ensure the user has the "STUDENT" role
        StudentDTO studentDTO = new StudentDTO(1L, "0", 0L, Set.of(1L));


        // Mock userService to return a valid user
        when(userService.findUserById(1L)).thenReturn(user);

        // Mock departmentRepository to return empty for department ID 1 (not found)
        when(departmentRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> studentService.saveStudent(studentDTO));
        assertEquals("Department not found with id: 1", exception.getMessage());
        verify(studentRepository, never()).save(any(Student.class));  // Ensure student is not saved
    }


    // --------------------------------------------
    // 4. Test: Update Student - Successful
    // --------------------------------------------
    /*
    @Test
    void testUpdateStudent_Successful() {
        // Arrange
        long studentId = 1L;
        Student existingStudent = new Student();
        existingStudent.setId(studentId);
        existingStudent.setFacultyNumber("F123456");

        StudentDTO updatedStudentDTO = new StudentDTO(1L, studentId, Set.of(1L), "F654321");

        User user = new User();
        user.setId(1L);
        user.setAuthorities(Set.of(new Role(1L, "ROLE_STUDENT")));  // Ensure the user has the "ROLE_STUDENT"

        Department department = new Department();
        department.setId(1L);

        when(userService.findUserById(1L)).thenReturn(user);
        when(studentRepository.findById(studentId)).thenReturn(Optional.of(existingStudent));
        when(departmentRepository.findAllById(List.of(1L))).thenReturn(List.of(department));
        when(studentRepository.save(any(Student.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Student updatedStudent = studentService.updateStudentById(studentId, updatedStudentDTO);

        // Assert
        assertNotNull(updatedStudent.getDepartments());
        assertEquals(1, updatedStudent.getDepartments().size(), "Departments size mismatch");  // Ensure department size matches
        assertEquals("F654321", updatedStudent.getFacultyNumber());  // Ensure faculty number updated
        verify(studentRepository, times(1)).save(existingStudent);
    }

     */


    // --------------------------------------------
    // 5. Test: Update Student - Student Not Found
    // --------------------------------------------
    @Test
    void testUpdateStudent_StudentNotFound() {
        // Arrange
        long studentId = 1L;
        StudentDTO updatedStudentDTO = new StudentDTO(1L, "0", 0L, Set.of(1L));


        // Mocking `userService` to return a valid `User` for the DTO
        User user = new User();
        user.setId(1L);
        user.setAuthorities(Set.of(new Role(1L, "ROLE_STUDENT")));  // Ensure the role is a "STUDENT"
        when(userService.findUserById(1L)).thenReturn(user);

        // Mock the student repository to return empty (no student with this ID)
        when(studentRepository.findById(studentId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> studentService.updateStudentById(studentId, updatedStudentDTO));
        assertEquals("Student not found with id: " + studentId, exception.getMessage());
        verify(studentRepository, never()).save(any(Student.class));
    }


    // --------------------------------------------
    // 6. Test: Find Student by ID - Success
    // --------------------------------------------
    @Test
    void testFindStudentById_Success() {
        // Arrange
        long studentId = 1L;
        Student student = new Student();
        student.setId(studentId);
        student.setFacultyNumber("F123456");

        when(studentRepository.findById(studentId)).thenReturn(Optional.of(student));

        // Act
        Optional<Student> result = studentService.findStudentById(studentId);

        // Assert
        assertNotNull(result);
        assertEquals("F123456", result.get().getFacultyNumber());
        verify(studentRepository, times(1)).findById(studentId);
    }

    // --------------------------------------------
    // 7. Test: Find Student by ID - Not Found
    // --------------------------------------------
    @Test
    void testFindStudentById_NotFound() {
        // Arrange
        long studentId = 1L;
        when(studentRepository.findById(studentId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> studentService.findStudentById(studentId));
        assertEquals("Student not found with id: " + studentId, exception.getMessage());
        verify(studentRepository, times(1)).findById(studentId);
    }

    // --------------------------------------------
    // 8. Test: Delete Student - Successful
    // --------------------------------------------
    @Test
    void testDeleteStudentById_Successful() {
        // Arrange
        long studentId = 1L;

        Student student = new Student();
        student.setId(studentId);
        student.setDepartments(Set.of());  // Empty set for simplicity

        when(studentRepository.existsById(studentId)).thenReturn(true);
        when(studentRepository.findById(studentId)).thenReturn(Optional.of(student));  // Mock the actual student retrieval

        // Act
        studentService.deleteStudentById(studentId);

        // Assert
        verify(studentRepository, times(1)).deleteById(studentId);  // Ensure the student is deleted
    }


    // --------------------------------------------
    // 9. Test: Delete Student - Not Found
    // --------------------------------------------
    @Test
    void testDeleteStudentById_NotFound() {
        // Arrange
        long studentId = 1L;
        when(studentRepository.existsById(studentId)).thenReturn(false);

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> studentService.deleteStudentById(studentId));
        assertEquals("Student not found with id: " + studentId, exception.getMessage());
        verify(studentRepository, never()).deleteById(studentId);
    }

    // --------------------------------------------
    // 10. Test: Find All Students
    // --------------------------------------------
    @Test
    void testFindAllStudents() {
        // Arrange
        List<Student> students = List.of(new Student(1L, "F123456", null, null, null), new Student(2L, "F654321", null, null, null));
        when(studentRepository.findAll()).thenReturn(students);

        // Act
        List<Student> result = studentService.findAllStudents();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(studentRepository, times(1)).findAll();
    }
}
