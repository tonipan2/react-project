package com.example.graduate.service;

import com.example.graduate.dto.UserDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.*;
import com.example.graduate.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @InjectMocks
    private UserService userService; // The service under test

    @Mock
    private UserRepository userRepository; // Mocked dependencies

    @Mock
    private RoleRepository roleRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    void testSaveUser_SuccessfulSave() {
        // Arrange
        UserDTO userDTO = new UserDTO(
                0L, "testUser", "Test@1234", "testuser@example.com",
                "1234567890", "John", "Doe", "1234567890",
                LocalDate.of(2000, 1, 1), "123 Test St",
                true, true, true, true,
                Set.of(new Role(1L, "ROLE_USER"))
        );

        // Mock behavior
        when(userRepository.findByEmail(userDTO.getEmail())).thenReturn(Optional.empty());
        when(userRepository.findByUsername(userDTO.getUsername())).thenReturn(Optional.empty());
        when(roleRepository.findByAuthority("ROLE_USER")).thenReturn(Optional.of(new Role(1L, "ROLE_USER")));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        User savedUser = userService.saveUser(userDTO);

        // Assert
        assertNotNull(savedUser);
        assertEquals("testUser", savedUser.getUsername());
        assertEquals("testuser@example.com", savedUser.getEmail());
        assertTrue(new BCryptPasswordEncoder().matches("Test@1234", savedUser.getPassword())); // Password check
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void testSaveUser_EmailAlreadyExists() {
        // Arrange
        UserDTO userDTO = new UserDTO();
        userDTO.setEmail("existinguser@example.com");
        userDTO.setUsername("uniqueUsername");

        when(userRepository.findByEmail(userDTO.getEmail())).thenReturn(Optional.of(new User()));

        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> userService.saveUser(userDTO));
        assertEquals("Email already exists", exception.getMessage());
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void testSaveUser_UsernameAlreadyExists() {
        // Arrange
        UserDTO userDTO = new UserDTO();
        userDTO.setUsername("existingUsername");
        userDTO.setEmail("uniqueuser@example.com");

        when(userRepository.findByUsername(userDTO.getUsername())).thenReturn(Optional.of(new User()));

        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> userService.saveUser(userDTO));
        assertEquals("Username already exists", exception.getMessage());
        verify(userRepository, never()).save(any(User.class));
    }

    // --------------------------------------------
    // 1. Test: Successful user update
    // --------------------------------------------
    @Test
    void testUpdateUser_SuccessfulUpdate() {
        // Arrange
        long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUsername("oldUsername");
        existingUser.setPassword(new BCryptPasswordEncoder().encode("OldPassword123"));
        existingUser.setEmail("oldemail@example.com");

        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setUsername("newUsername");
        updatedUserDTO.setPassword("NewPassword@123");
        updatedUserDTO.setEmail("newemail@example.com");
        updatedUserDTO.setAuthorities(Set.of(new Role(1L, "ROLE_USER")));

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));
        when(roleRepository.findByAuthority("ROLE_USER")).thenReturn(Optional.of(new Role(1L, "ROLE_USER")));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        User updatedUser = userService.updateUserById(userId, updatedUserDTO);

        // Assert
        assertEquals("newUsername", updatedUser.getUsername());
        assertEquals("newemail@example.com", updatedUser.getEmail());
        assertTrue(new BCryptPasswordEncoder().matches("NewPassword@123", updatedUser.getPassword()));
        assertEquals(1, updatedUser.getAuthorities().size());
        assertTrue(updatedUser.getAuthorities().stream().anyMatch(role -> role.getAuthority().equals("ROLE_USER")));
    }

    // --------------------------------------------
    // 2. Test: User not found
    // --------------------------------------------
    @Test
    void testUpdateUser_UserNotFound() {
        // Arrange
        long userId = 1L;
        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setUsername("newUsername");

        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> userService.updateUserById(userId, updatedUserDTO));
        assertEquals("User not found with id: " + userId, exception.getMessage());
    }

    // --------------------------------------------
    // 3. Test: Role not found for update
    // --------------------------------------------
    @Test
    void testUpdateUser_RoleNotFound() {
        // Arrange
        long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUsername("oldUsername");
        existingUser.setPassword(new BCryptPasswordEncoder().encode("OldPassword123"));

        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setAuthorities(Set.of(new Role(2L, "ROLE_INVALID")));

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));
        when(roleRepository.findByAuthority("ROLE_INVALID")).thenReturn(Optional.empty());

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> userService.updateUserById(userId, updatedUserDTO));
        assertEquals("Invalid Role: ROLE_INVALID", exception.getMessage());
        verify(userRepository, never()).save(any(User.class));  // Ensure user is not saved
    }

    // --------------------------------------------
    // 4. Test: No password change if same
    // --------------------------------------------
    @Test
    void testUpdateUser_SamePassword_NoChange() {
        // Arrange
        long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUsername("oldUsername");
        existingUser.setPassword(new BCryptPasswordEncoder().encode("OldPassword123"));

        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setPassword("OldPassword123"); // Same password

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));

        // Act
        User updatedUser = userService.updateUserById(userId, updatedUserDTO);

        // Assert
        assertEquals(existingUser.getPassword(), updatedUser.getPassword());
        verify(userRepository, times(1)).save(any(User.class)); // User should still be saved
    }

    // --------------------------------------------
    // 5. Test: Partial update (only username and email)
    // --------------------------------------------
    @Test
    void testUpdateUser_PartialUpdate() {
        // Arrange
        long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUsername("oldUsername");
        existingUser.setEmail("oldemail@example.com");

        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setUsername("newUsername");
        updatedUserDTO.setEmail("newemail@example.com");

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        User updatedUser = userService.updateUserById(userId, updatedUserDTO);

        // Assert
        assertEquals("newUsername", updatedUser.getUsername());
        assertEquals("newemail@example.com", updatedUser.getEmail());
        assertEquals(existingUser.getPassword(), updatedUser.getPassword()); // Password should remain unchanged
    }

    // --------------------------------------------
    // 6. Test: Update with null fields
    // --------------------------------------------
    @Test
    void testUpdateUser_NullFields() {
        // Arrange
        long userId = 1L;
        User existingUser = new User();
        existingUser.setId(userId);
        existingUser.setUsername("oldUsername");
        existingUser.setEmail("oldemail@example.com");

        UserDTO updatedUserDTO = new UserDTO();
        updatedUserDTO.setUsername(null); // Null username should be ignored
        updatedUserDTO.setEmail(null);    // Null email should be ignored

        when(userRepository.findById(userId)).thenReturn(Optional.of(existingUser));

        // Act
        User updatedUser = userService.updateUserById(userId, updatedUserDTO);

        // Assert
        assertEquals("oldUsername", updatedUser.getUsername());
        assertEquals("oldemail@example.com", updatedUser.getEmail());
    }
}



