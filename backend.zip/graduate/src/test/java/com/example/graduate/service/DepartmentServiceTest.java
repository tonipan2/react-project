package com.example.graduate.service;

import com.example.graduate.dto.DepartmentDTO;
import com.example.graduate.model.Department;
import com.example.graduate.repository.DepartmentRepository;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DepartmentServiceTest {


    @InjectMocks
    private DepartmentService departmentService;

    @Mock
    private DepartmentRepository departmentRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void saveDepartment_ShouldReturnSavedDepartment() {
        DepartmentDTO departmentDTO = new DepartmentDTO();
        departmentDTO.setDepartmentName("Computer Science");

        Department savedDepartment = new Department();
        savedDepartment.setDepartmentName("Computer Science");

        when(departmentRepo.save(any(Department.class))).thenReturn(savedDepartment);

        Department result = departmentService.saveDepartment(departmentDTO);

        assertEquals("Computer Science", result.getDepartmentName());
        verify(departmentRepo, times(1)).save(any(Department.class));
    }

    @Test
    void updateDepartmentById_ShouldUpdateAndReturnDepartment() {
        long departmentId = 1L;

        Department existingDepartment = new Department();
        existingDepartment.setDepartmentName("Old Department");

        DepartmentDTO updatedDepartmentDTO = new DepartmentDTO();
        updatedDepartmentDTO.setDepartmentName("New Department");

        when(departmentRepo.findById(departmentId)).thenReturn(Optional.of(existingDepartment));
        when(departmentRepo.save(existingDepartment)).thenReturn(existingDepartment);

        Department updatedDepartment = departmentService.updateDepartmentById(departmentId, updatedDepartmentDTO);

        assertEquals("New Department", updatedDepartment.getDepartmentName());
        verify(departmentRepo, times(1)).findById(departmentId);
        verify(departmentRepo, times(1)).save(existingDepartment);
    }

    @Test
    void updateDepartmentById_ShouldThrowException_WhenDepartmentNotFound() {
        long departmentId = 1L;

        DepartmentDTO updatedDepartmentDTO = new DepartmentDTO();
        updatedDepartmentDTO.setDepartmentName("New Department");

        when(departmentRepo.findById(departmentId)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () ->
                departmentService.updateDepartmentById(departmentId, updatedDepartmentDTO));

        verify(departmentRepo, times(1)).findById(departmentId);
        verify(departmentRepo, times(0)).save(any(Department.class));
    }

    @Test
    void deleteDepartmentById_ShouldDeleteDepartment() {
        long departmentId = 1L;

        when(departmentRepo.existsById(departmentId)).thenReturn(true);

        departmentService.deleteDepartmentById(departmentId);

        verify(departmentRepo, times(1)).deleteById(departmentId);
    }

    @Test
    void deleteDepartmentById_ShouldThrowException_WhenDepartmentNotFound() {
        long departmentId = 1L;

        when(departmentRepo.existsById(departmentId)).thenReturn(false);

        assertThrows(EntityNotFoundException.class, () ->
                departmentService.deleteDepartmentById(departmentId));

        verify(departmentRepo, times(0)).deleteById(departmentId);
    }

    @Test
    void findDepartmentById_ShouldReturnDepartment() {
        long departmentId = 1L;
        Department department = new Department();
        department.setDepartmentName("Mathematics");

        when(departmentRepo.findById(departmentId)).thenReturn(Optional.of(department));

        Optional<Department> result = departmentService.findDepartmentById(departmentId);

        assertEquals("Mathematics", result.get().getDepartmentName());
        verify(departmentRepo, times(1)).findById(departmentId);
    }

    @Test
    void findDepartmentById_ShouldThrowException_WhenDepartmentNotFound() {
        long departmentId = 1L;

        when(departmentRepo.findById(departmentId)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () ->
                departmentService.findDepartmentById(departmentId));

        verify(departmentRepo, times(1)).findById(departmentId);
    }


    @Test
    void findAllDepartments_ShouldReturnListOfDepartments() {
        List<Department> departments = List.of(
                new Department(1L, "Physics"),
                new Department(2L, "Chemistry")
        );

        when(departmentRepo.findAll()).thenReturn(departments);

        List<Department> result = departmentService.findAllDepartments();

        assertEquals(2, result.size());
        verify(departmentRepo, times(1)).findAll();
    }

    @Test
    void doesDepartmentExist_ShouldReturnTrue_WhenExists() {
        long departmentId = 1L;

        when(departmentRepo.existsById(departmentId)).thenReturn(true);

        boolean exists = departmentService.doesDepartmentExist(departmentId);

        assertTrue(exists);
        verify(departmentRepo, times(1)).existsById(departmentId);
    }

    @Test
    void doesDepartmentExist_ShouldReturnFalse_WhenNotExists() {
        long departmentId = 1L;

        when(departmentRepo.existsById(departmentId)).thenReturn(false);

        boolean exists = departmentService.doesDepartmentExist(departmentId);

        assertFalse(exists);
        verify(departmentRepo, times(1)).existsById(departmentId);
    }
}
