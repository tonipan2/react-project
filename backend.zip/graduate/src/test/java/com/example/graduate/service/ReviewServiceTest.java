package com.example.graduate.service;

import com.example.graduate.dto.ReviewDTO;
import com.example.graduate.model.Review;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.Thesis;
import com.example.graduate.repository.ReviewRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import com.example.graduate.service.ReviewService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReviewServiceTest {

    @Mock
    private ReviewRepository reviewRepo;

    @Mock
    private ThesisRepository thesisRepo;

    @Mock
    private TeacherRepository teacherRepo;

    @InjectMocks
    private ReviewService reviewService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveReview() {
        // Arrange
        ReviewDTO reviewDTO = new ReviewDTO();
        reviewDTO.setText("Sample review");
        reviewDTO.setDateUploaded(LocalDate.now());
        reviewDTO.setConclusion(true);
        reviewDTO.setThesisId(1L);
        reviewDTO.setTeacherId(2L);

        Thesis thesis = new Thesis();
        thesis.setId(1L);

        Teacher teacher = new Teacher();
        teacher.setId(2L);

        when(thesisRepo.findById(1L)).thenReturn(Optional.of(thesis));
        when(teacherRepo.findById(2L)).thenReturn(Optional.of(teacher));
        when(reviewRepo.save(any(Review.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Review result = reviewService.saveReview(reviewDTO);

        // Assert
        assertNotNull(result);
        assertEquals("Sample review", result.getText());
        assertEquals(LocalDate.now(), result.getDateUploaded());
        assertTrue(result.getConclusion());
        assertEquals(thesis, result.getThesis());
        assertEquals(teacher, result.getTeacher());

        verify(reviewRepo, times(1)).save(any(Review.class));
    }

    @Test
    void testUpdateReviewById() {
        // Arrange
        long reviewId = 1L;

        Review existingReview = new Review();
        existingReview.setId(reviewId);
        existingReview.setText("Old text");
        existingReview.setDateUploaded(LocalDate.of(2025, 1, 1));
        existingReview.setConclusion(false);

        ReviewDTO updatedReviewDTO = new ReviewDTO();
        updatedReviewDTO.setText("Updated text");
        updatedReviewDTO.setConclusion(true);
        updatedReviewDTO.setThesisId(1L);
        updatedReviewDTO.setTeacherId(2L);

        Thesis thesis = new Thesis();
        thesis.setId(1L);

        Teacher teacher = new Teacher();
        teacher.setId(2L);

        when(reviewRepo.findById(reviewId)).thenReturn(Optional.of(existingReview));
        when(thesisRepo.findById(1L)).thenReturn(Optional.of(thesis));
        when(teacherRepo.findById(2L)).thenReturn(Optional.of(teacher));
        when(reviewRepo.save(any(Review.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Review result = reviewService.updateReviewById(reviewId, updatedReviewDTO);

        // Assert
        assertNotNull(result);
        assertEquals("Updated text", result.getText());
        assertTrue(result.getConclusion());
        assertEquals(thesis, result.getThesis());
        assertEquals(teacher, result.getTeacher());

        verify(reviewRepo, times(1)).save(any(Review.class));
    }

    @Test
    void testDeleteReviewById() {
        // Arrange
        long reviewId = 1L;

        when(reviewRepo.existsById(reviewId)).thenReturn(true);

        // Act
        reviewService.deleteReviewById(reviewId);

        // Assert
        verify(reviewRepo, times(1)).deleteById(reviewId);
    }

    @Test
    void testDeleteReviewById_NotFound() {
        // Arrange
        long reviewId = 1L;

        when(reviewRepo.existsById(reviewId)).thenReturn(false);

        // Act & Assert
        assertThrows(EntityNotFoundException.class, () -> reviewService.deleteReviewById(reviewId));
    }

    @Test
    void testFindReviewById() {
        // Arrange
        long reviewId = 1L;

        Review review = new Review();
        review.setId(reviewId);

        when(reviewRepo.findById(reviewId)).thenReturn(Optional.of(review));

        // Act
        Optional<Review> result = reviewService.findReviewById(reviewId);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(reviewId, result.get().getId());
    }

    @Test
    void testFindReviewById_NotFound() {
        // Arrange
        long reviewId = 1L;

        when(reviewRepo.findById(reviewId)).thenReturn(Optional.empty());

        // Act
        Optional<Review> result = reviewService.findReviewById(reviewId);

        // Assert
        assertTrue(result.isEmpty());
    }

    @Test
    void testCountStudentsWithNegativeReviews() {
        // Arrange
        long count = 5L;

        when(reviewRepo.countStudentsWithNegativeReviews()).thenReturn(count);

        // Act
        long result = reviewService.countStudentsWithNegativeReviews();

        // Assert
        assertEquals(count, result);
        verify(reviewRepo, times(1)).countStudentsWithNegativeReviews();
    }
}
