package com.example.graduate.controller;

public class TeacherControllerTest {
}
