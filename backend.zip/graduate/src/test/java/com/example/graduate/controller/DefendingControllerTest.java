package com.example.graduate.controller;

import com.example.graduate.GraduateApplication;
import com.example.graduate.controller.ApplicationController;
import com.example.graduate.controller.DefendingController;
import com.example.graduate.dto.DefendingDTO;
import com.example.graduate.model.Application;
import com.example.graduate.model.Defending;
import com.example.graduate.service.DefendingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
class DefendingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DefendingService defendingService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testAddDefending() throws Exception {
        DefendingDTO defendingDTO = new DefendingDTO(0L, LocalDate.of(2025, 1, 10), Collections.emptySet());
        Defending savedDefending = new Defending(1L, LocalDate.of(2025, 1, 10), null, Collections.emptySet());

        Mockito.when(defendingService.saveDefending(any(DefendingDTO.class), eq(1L))).thenReturn(savedDefending);

        mockMvc.perform(post("/defending/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(defendingDTO))
                        .param("teacherId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.dateDefending").value("2025-01-10"));
    }

    @Test
    void testPatchDefending() throws Exception {
        DefendingDTO updatedDTO = new DefendingDTO(1L, LocalDate.of(2025, 2, 15), Collections.emptySet());
        Defending updatedDefending = new Defending(1L, LocalDate.of(2025, 2, 15), null, Collections.emptySet());

        Mockito.when(defendingService.updateDefendingById(eq(1L), any(DefendingDTO.class))).thenReturn(updatedDefending);

        mockMvc.perform(patch("/defending/edit/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updatedDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.dateDefending").value("2025-02-15"));
    }

    @Test
    void testDeleteDefending() throws Exception {
        Mockito.doNothing().when(defendingService).deleteDefendingById(1L);

        mockMvc.perform(delete("/defending/delete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("The Defending has been deleted"));
    }

    @Test
    void testFetchAll() throws Exception {
        Defending defending = new Defending(1L, LocalDate.of(2025, 1, 10), null, Collections.emptySet());
        Mockito.when(defendingService.findAllDefendings()).thenReturn(Collections.singletonList(defending));

        mockMvc.perform(get("/defending/fetch/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].dateDefending").value("2025-01-10"));
    }

    @Test
    void testFetchById() throws Exception {
        Defending defending = new Defending(1L, LocalDate.of(2025, 1, 10), null, Collections.emptySet());
        Mockito.when(defendingService.findDefendingById(1L)).thenReturn(Optional.of(defending));

        mockMvc.perform(get("/defending/fetch/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.dateDefending").value("2025-01-10"));
    }

    @Test
    void testFetchById_NotFound() throws Exception {
        Mockito.when(defendingService.findDefendingById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/defending/fetch/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAverageStudents() throws Exception {
        Mockito.when(defendingService.calculateAverageStudentsInPeriod(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31)))
                .thenReturn(10.0);

        mockMvc.perform(get("/defending/average-students")
                        .param("startDate", "2025-01-01")
                        .param("endDate", "2025-12-31"))
                .andExpect(status().isOk())
                .andExpect(content().string("10.0"));
    }
}
