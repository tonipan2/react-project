package com.example.graduate.controller;

import com.example.graduate.dto.DepartmentDTO;
import com.example.graduate.model.Department;
import com.example.graduate.security.TestSecurityConfig;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = DepartmentController.class)
@Import(TestSecurityConfig.class)
@AutoConfigureMockMvc(addFilters = false)
public class DepartmentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DepartmentService departmentService;

    @BeforeEach
    void setUp() {
        Mockito.when(departmentService.findDepartmentById(1L))
                .thenReturn(Optional.of(new Department(1L, "Physics")));

        Mockito.when(departmentService.findDepartmentById(2L))
                .thenReturn(Optional.empty());  // Simulate not found
    }

    @Test
    void testPostDepartment() throws Exception {
        DepartmentDTO departmentDTO = new DepartmentDTO(0, "Physics");
        Department department = new Department(1L, "Physics");

        Mockito.when(departmentService.saveDepartment(any(DepartmentDTO.class))).thenReturn(department);

        mockMvc.perform(post("/department/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"departmentName\":\"Physics\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.departmentName").value("Physics"));
    }

    @Test
    void testPatchDepartment() throws Exception {
        DepartmentDTO departmentDTO = new DepartmentDTO(0, "Mathematics");
        Department updatedDepartment = new Department(1L, "Mathematics");

        Mockito.when(departmentService.updateDepartmentById(eq(1L), any(DepartmentDTO.class))).thenReturn(updatedDepartment);

        mockMvc.perform(patch("/department/edit/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"departmentName\":\"Mathematics\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.departmentName").value("Mathematics"));
    }

    @Test
    void testDeleteDepartment() throws Exception {
        Mockito.doNothing().when(departmentService).deleteDepartmentById(1L);

        mockMvc.perform(delete("/department/delete/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("The Department has been deleted"));
    }

    @Test
    void testDeleteDepartmentNotFound() throws Exception {
        Mockito.doThrow(new EntityNotFoundException("Department not found with id: 1"))
                .when(departmentService).deleteDepartmentById(1L);

        mockMvc.perform(delete("/department/delete/1"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Department not found with id: 1"));
    }

    @Test
    void testFetchAllDepartments() throws Exception {
        Department department1 = new Department(1L, "Physics");
        Department department2 = new Department(2L, "Mathematics");

        Mockito.when(departmentService.findAllDepartments()).thenReturn(Arrays.asList(department1, department2));

        mockMvc.perform(get("/department/fetch/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].departmentName").value("Physics"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].departmentName").value("Mathematics"));
    }

    @Test
    void testFetchDepartmentById() throws Exception {
        Department department = new Department(1L, "Physics");

        Mockito.when(departmentService.findDepartmentById(1L))
                .thenReturn(Optional.empty());

        mockMvc.perform(get("/department/fetch/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.departmentName").value("Physics"));
    }

    @Test
    void testFetchDepartmentByIdNotFound() throws Exception {
        Mockito.when(departmentService.findDepartmentById(1L))
                .thenThrow(new EntityNotFoundException("Department not found with id: 1"));

        mockMvc.perform(get("/department/fetch/1"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Department not found with id: 1"));
    }
}
