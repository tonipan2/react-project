package com.example.graduate.service;

import com.example.graduate.dto.DefendingDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.DefendingRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import com.example.graduate.service.DefendingService;
import com.example.graduate.service.TeacherService;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DefendingServiceTest {

    @InjectMocks
    private DefendingService defendingService;

    @Mock
    private DefendingRepository defendingRepo;

    @Mock
    private TeacherRepository teacherRepo;

    @Mock
    private TeacherService teacherService;

    @Mock
    private ThesisRepository thesisRepo;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveDefending() {
        Long teacherId = 1L;
        DefendingDTO defendingDTO = new DefendingDTO();
        defendingDTO.setDateDefending(LocalDate.of(2025, 1, 10));

        Set<Teacher> teachers = new HashSet<>();
        Teacher teacher = new Teacher();
        teacher.setId(teacherId);
        teachers.add(teacher);

        when(teacherService.findAllByDepartment(teacherId)).thenReturn(teachers);
        when(defendingRepo.save(any(Defending.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Defending result = defendingService.saveDefending(defendingDTO, teacherId);

        assertNotNull(result);
        assertEquals(LocalDate.of(2025, 1, 10), result.getDateDefending());
        assertEquals(teachers, result.getTeachers());

        verify(defendingRepo, times(1)).save(any(Defending.class));
    }

    @Test
    void testUpdateDefendingById() {
        long defendingId = 1L;
        Defending existingDefending = new Defending();
        existingDefending.setId(defendingId);

        DefendingDTO updatedDefendingDTO = new DefendingDTO();
        updatedDefendingDTO.setTeacherIds(Set.of(1L, 2L));

        Teacher teacher1 = new Teacher();
        teacher1.setId(1L);
        Teacher teacher2 = new Teacher();
        teacher2.setId(2L);

        when(defendingRepo.findById(defendingId)).thenReturn(Optional.of(existingDefending));
        when(teacherRepo.findAllById(updatedDefendingDTO.getTeacherIds())).thenReturn(List.of(teacher1, teacher2));
        when(defendingRepo.save(any(Defending.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Defending result = defendingService.updateDefendingById(defendingId, updatedDefendingDTO);

        assertNotNull(result);
        assertEquals(2, result.getTeachers().size());
        assertTrue(result.getTeachers().contains(teacher1));
        assertTrue(result.getTeachers().contains(teacher2));

        verify(defendingRepo, times(1)).save(existingDefending);
    }

    @Test
    void testDeleteDefendingById() {
        long defendingId = 1L;

        when(defendingRepo.existsById(defendingId)).thenReturn(true);

        defendingService.deleteDefendingById(defendingId);

        verify(defendingRepo, times(1)).deleteById(defendingId);
    }

    @Test
    void testDeleteDefendingById_NotFound() {
        long defendingId = 1L;

        when(defendingRepo.existsById(defendingId)).thenReturn(false);

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            defendingService.deleteDefendingById(defendingId);
        });

        assertEquals("Defending not found with id: " + defendingId, exception.getMessage());

        verify(defendingRepo, never()).deleteById(defendingId);
    }

    @Test
    void testCalculateAverageStudentsInPeriod() {
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 1, 31);

        Defending defending = new Defending();
        ThesisDefending thesisDefending = new ThesisDefending();
        Thesis thesis = new Thesis();
        Application application = new Application();
        Student student = new Student();

        student.setId(1L);
        application.setStudent(student);
        thesis.setApplication(application);
        thesisDefending.setThesis(thesis);
        defending.setThesisDefendings(Set.of(thesisDefending));

        when(defendingRepo.findDefendingsWithinPeriod(startDate, endDate)).thenReturn(List.of(defending));

        double average = defendingService.calculateAverageStudentsInPeriod(startDate, endDate);

        assertEquals(1.0, average);

        verify(defendingRepo, times(1)).findDefendingsWithinPeriod(startDate, endDate);
    }
}
