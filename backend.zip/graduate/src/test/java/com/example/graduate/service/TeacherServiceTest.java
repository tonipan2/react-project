package com.example.graduate.service;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.graduate.dto.RoleDTO;
import com.example.graduate.dto.TeacherDTO;
import com.example.graduate.dto.UserDTO;
import com.example.graduate.model.Department;
import com.example.graduate.model.Position;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.User;
import com.example.graduate.model.Role;
import com.example.graduate.repository.DepartmentRepository;
import com.example.graduate.repository.RoleRepository;
import com.example.graduate.repository.TeacherRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import jakarta.persistence.EntityNotFoundException;

import java.util.List;
import java.util.Optional;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@ContextConfiguration(classes = TeacherServiceTest.Config.class)
public class TeacherServiceTest {
    @InjectMocks
    private TeacherService teacherService;

    @Mock
    private TeacherRepository teacherRepo;

    @Mock
    private UserService userService;

    @Mock
    private DepartmentRepository departmentRepo;

    @Mock
    private RoleRepository roleRepo;

    @Mock
    private DepartmentService departmentService;

    @Mock
    private StudentService studentService;

    private TeacherDTO teacherDTO;
    private Teacher teacher;
    private User user;
    private Department department;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Set up a test user
        user = new User();
        user.setId(1L);
        user.setUsername("teacher1");

        // Set up a test department
        department = new Department();
        department.setId(1L);
        department.setDepartmentName("Math");

        // Set up a TeacherDTO
        teacherDTO = new TeacherDTO(1L, 1L, new HashSet<>(Set.of(1L)), "T12345", Position.PROFESSOR);

        // Set up a Teacher
        teacher = new Teacher();
        teacher.setId(1L);
        teacher.setUser(user);
        teacher.setFacultyNumber("T12345");
        teacher.setPosition(Position.PROFESSOR);
        teacher.setDepartments(new HashSet<>(Set.of(department)));
    }

    @Test
    void testSaveTeacher() {
        // Mock the role repository to return the appropriate role
        Role teacherRole = new Role();
        teacherRole.setAuthority("ROLE_TEACHER");
        when(roleRepo.findByAuthority("ROLE_TEACHER")).thenReturn(Optional.of(teacherRole));

        // Prepare the user DTO with the ROLE_TEACHER authority
        UserDTO userDTO = new UserDTO();
        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setAuthority("ROLE_TEACHER");
        userDTO.setAuthorities(Set.of()); // Set the correct authority in the DTO

        // Map the authorities to actual Role entities
        Set<Role> authorities = userDTO.getAuthorities().stream()
                .map(dto -> roleRepo.findByAuthority(dto.getAuthority())
                        .orElseThrow(() -> new IllegalArgumentException("Invalid Role: " + dto.getAuthority())))
                .collect(Collectors.toSet());
        user.setAuthorities(authorities); // Set the authorities for the user

        // Mock the user service to return the user with the correct roles
        when(userService.findUserById(teacherDTO.getUserId())).thenReturn(user);

        // Mock department repository and teacher repository
        when(departmentRepo.findAllById(teacherDTO.getDepartmentIds())).thenReturn(List.of(department));
        when(teacherRepo.save(any(Teacher.class))).thenReturn(teacher);

        // Call the method under test
        Teacher savedTeacher = teacherService.saveTeacher(teacherDTO);

        // Assertions
        assertNotNull(savedTeacher);
        assertEquals("T12345", savedTeacher.getFacultyNumber());
        assertEquals(Position.PROFESSOR, savedTeacher.getPosition());
        assertEquals(1, savedTeacher.getDepartments().size());

        // Verify interactions
        verify(teacherRepo, times(1)).save(any(Teacher.class));
    }



    @Test
    void testUpdateTeacher() {
        when(userService.findUserById(teacherDTO.getUserId())).thenReturn(user);
        when(departmentRepo.findAllById(teacherDTO.getDepartmentIds())).thenReturn((List<Department>) Set.of(department));
        when(teacherRepo.findById(1L)).thenReturn(Optional.of(teacher));
        when(teacherRepo.save(any(Teacher.class))).thenReturn(teacher);

        teacherDTO.setFacultyNumber("T67890");
        teacherDTO.setPosition(Position.PROFESSOR);

        Teacher updatedTeacher = teacherService.updateTeacherById(1L, teacherDTO);

        assertEquals("T67890", updatedTeacher.getFacultyNumber());
        assertEquals(Position.PROFESSOR, updatedTeacher.getPosition());

        verify(teacherRepo, times(1)).save(any(Teacher.class));
    }

    @Test
    void testDeleteTeacher() {
        when(teacherRepo.findById(1L)).thenReturn(Optional.of(teacher));
        doNothing().when(teacherRepo).deleteById(1L);

        teacherService.deleteTeacherById(1L);

        verify(teacherRepo, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteTeacherNotFound() {
        when(teacherRepo.findById(1L)).thenReturn(Optional.empty());

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            teacherService.deleteTeacherById(1L);
        });

        assertEquals("Teacher not found with id: 1", exception.getMessage());
    }

    @Test
    void testFindTeacherById() {
        when(teacherRepo.findById(1L)).thenReturn(Optional.of(teacher));

        Teacher foundTeacher = teacherService.findTeacherById(1L);

        assertNotNull(foundTeacher);
        assertEquals(1L, foundTeacher.getId());
    }

    @Test
    void testFindTeacherByIdNotFound() {
        when(teacherRepo.findById(1L)).thenReturn(Optional.empty());

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {
            teacherService.findTeacherById(1L);
        });

        assertEquals("Teacher not found with id: 1", exception.getMessage());
    }

    @Test
    void testDoesTeacherExist() {
        when(teacherRepo.existsById(1L)).thenReturn(true);

        boolean exists = teacherService.doesTeacherExist(1L);

        assertTrue(exists);

        verify(teacherRepo, times(1)).existsById(1L);
    }

    @Test
    void testDoesTeacherExistNotFound() {
        when(teacherRepo.existsById(1L)).thenReturn(false);

        boolean exists = teacherService.doesTeacherExist(1L);

        assertFalse(exists);

        verify(teacherRepo, times(1)).existsById(1L);
    }

    @Test
    void testValidateRoleIsTeacher() {
        when(userService.findUserById(1L)).thenReturn(user);

        teacherService.validateRoleIsTeacher(user);

        // No exception should be thrown, so the test passes if this line is reached.
    }

    @Test
    void testValidateRoleIsNotTeacher() {
        User nonTeacherUser = new User();
        nonTeacherUser.setUsername("nonTeacher");

        when(userService.findUserById(1L)).thenReturn(nonTeacherUser);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            teacherService.validateRoleIsTeacher(nonTeacherUser);
        });

        assertEquals("Role must be teacher to assign account to a teacher", exception.getMessage());
    }
    @Configuration
    static class Config {
        // Define any required beans for testing
    }
}
