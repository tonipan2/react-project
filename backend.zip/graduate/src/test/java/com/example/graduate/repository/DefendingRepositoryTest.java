package com.example.graduate.repository;

import com.example.graduate.GraduateApplication;
import com.example.graduate.model.Defending;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.Thesis;
import com.example.graduate.model.ThesisDefending;
import com.example.graduate.model.Application;
import com.example.graduate.model.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ContextConfiguration(classes = GraduateApplication.class)
public class DefendingRepositoryTest {

    @Autowired
    private DefendingRepository defendingRepo;

    @Autowired
    private ThesisRepository thesisRepo;

    private Defending defending;

    @Autowired
    private TeacherRepository teacherRepo;

    @BeforeEach
    public void setUp() {
        // Create Teacher
        Teacher teacher = new Teacher();
        teacher.setId(1);

        // Mock save behavior for teacher
        when(teacherRepo.save(teacher)).thenReturn(teacher);
        when(teacherRepo.findById(anyLong())).thenReturn(Optional.of(teacher));

        // Create Student
        Student student = new Student();
        student.setId(1);

        // Create Application and Thesis
        Application application = new Application();
        application.setStudent(student);

        Thesis thesis = new Thesis();
        thesis.setApplication(application);
        thesisRepo.save(thesis);

        // Create ThesisDefending
        ThesisDefending thesisDefending = new ThesisDefending();
        thesisDefending.setThesis(thesis);

        // Create Defending
        defending = new Defending();
        defending.setDateDefending(LocalDate.of(2025, 5, 20));
        defending.getThesisDefendings().add(thesisDefending);
        defendingRepo.save(defending);

        // Link Teacher to Defending
        teacher.getDefendings().add(defending);
    }


    @Test
    public void testFindDefendingById() {
        // Given: Create a Defending entity to be tested
        Defending defending = new Defending();
        defending.setDateDefending(LocalDate.of(2025, 1, 16));
        // Add other properties as needed

        // Persist the Defending entity
        defendingRepo.save(defending);

        // When: Find Defending by ID
        Defending foundDefending = defendingRepo.findById(defending.getId()).orElse(null);

        // Then: Verify the retrieved Defending is correct
        assertThat(foundDefending).isNotNull();
        assertThat(foundDefending.getId()).isEqualTo(defending.getId());
        assertThat(foundDefending.getDateDefending()).isEqualTo(defending.getDateDefending());
    }

    @Test
    public void testFindDefendingsWithinPeriod() {
        // Query Defendings within a period
        LocalDate startDate = LocalDate.of(2025, 1, 1);
        LocalDate endDate = LocalDate.of(2025, 12, 31);
        List<Defending> defendings = defendingRepo.findDefendingsWithinPeriod(startDate, endDate);

        assertThat(defendings).isNotEmpty();
        assertThat(defendings.size()).isEqualTo(1);
        assertThat(defendings.get(0).getDateDefending()).isEqualTo(defending.getDateDefending());
    }

    @Test
    public void testExistsById() {
        // Check if Defending exists by ID
        boolean exists = defendingRepo.existsById(defending.getId());
        assertThat(exists).isTrue();
    }

    @Test
    public void testDeleteDefending() {
        // Delete the defending and check if it exists
        defendingRepo.delete(defending);

        boolean exists = defendingRepo.existsById(defending.getId());
        assertThat(exists).isFalse();
    }

    @Test
    public void testFindAllDefendings() {
        // Fetch all defendings
        List<Defending> allDefendings = defendingRepo.findAll();

        assertThat(allDefendings).isNotEmpty();
        assertThat(allDefendings).contains(defending);
    }
}
