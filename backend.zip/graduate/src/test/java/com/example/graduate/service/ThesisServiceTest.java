package com.example.graduate.service;

import com.example.graduate.dto.ThesisDTO;
import com.example.graduate.service.ThesisService;
import com.example.graduate.model.*;
import com.example.graduate.repository.*;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ThesisServiceTest {

    @InjectMocks
    private ThesisService thesisService; // The service under test

    @Mock
    private ThesisRepository thesisRepository;

    @Mock
    private ApplicationRepository applicationRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    // --------------------------------------------
    // 1. Test: Save Thesis - Successful
    // --------------------------------------------
    @Test
    public void testSaveThesis_Successful() {
        // Setup: Create a Thesis object
        ThesisDTO thesis = new ThesisDTO();
        thesis.setName("Thesis Title");

        // Call the method to save the thesis
        Thesis savedThesis = thesisService.saveThesis(thesis);

        // Assert that the title is saved correctly
        Assertions.assertEquals("Thesis Title", savedThesis.getName());
    }

    // --------------------------------------------
    // 2. Test: Save Thesis - Application Not Found
    // --------------------------------------------
    @Test
    void testSaveThesis_ApplicationNotFound() {
        // Arrange: Create ThesisDTO with correct applicationId (1L)
        ThesisDTO thesisDTO = new ThesisDTO(0L, "Thesis Title", "Thesis Text", null, Set.of(), 1L, Set.of());

        // Mock the applicationRepository to return an empty Optional for the applicationId 1L
        when(applicationRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verify the correct exception is thrown
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> thesisService.saveThesis(thesisDTO));

        // Assert: Check that the exception message contains the correct applicationId (1L)
        assertEquals("Application not found for ID: 0", exception.getMessage());

        // Verify that the save method of thesisRepository was never called
        verify(thesisRepository, never()).save(any(Thesis.class));
    }



    // --------------------------------------------
    // 3. Test: Update Thesis - Successful
    // --------------------------------------------
    @Test
    void testUpdateThesis_Successful() {
        // Arrange
        long thesisId = 1L;
        Thesis existingThesis = new Thesis(thesisId, "Old Title", "Old Text", LocalDate.of(2023, 1, 1), null, null, null);

        // Ensure proper ThesisDTO initialization with the correct applicationId
        ThesisDTO updatedThesisDTO = new ThesisDTO(1L, "Updated Title", "Updated Text", null, Set.of(), 1L, Set.of());

        Application application = new Application();
        application.setId(1L);  // Ensure the application ID is 1L

        when(thesisRepository.findById(thesisId)).thenReturn(Optional.of(existingThesis));
        when(applicationRepository.findById(1L)).thenReturn(Optional.of(application));
        when(thesisRepository.save(any(Thesis.class))).thenAnswer(invocation -> invocation.getArgument(0)); // Return the updated thesis

        // Act
        Thesis updatedThesis = thesisService.updateThesisById(thesisId, updatedThesisDTO);

        // Assert that the fields are correctly updated
        assertEquals("Updated Title", updatedThesis.getName());
        assertEquals("Updated Text", updatedThesis.getText());
        assertEquals(application, updatedThesis.getApplication()); // Verify the application is correctly set
        verify(thesisRepository, times(1)).save(updatedThesis); // Ensure the updated thesis is saved
    }



    // --------------------------------------------
    // 4. Test: Update Thesis - Thesis Not Found
    // --------------------------------------------
    @Test
    void testUpdateThesis_ThesisNotFound() {
        // Arrange
        long thesisId = 1L;
        ThesisDTO updatedThesisDTO = new ThesisDTO(1L, "Updated Title", "Updated Text", null, Set.of(), 1L, Set.of());

        when(thesisRepository.findById(thesisId)).thenReturn(Optional.empty());

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> thesisService.updateThesisById(thesisId, updatedThesisDTO));
        assertEquals("Thesis not found with id: " + thesisId, exception.getMessage());
        verify(thesisRepository, never()).save(any(Thesis.class));
    }

    // --------------------------------------------
    // 5. Test: Delete Thesis - Successful
    // --------------------------------------------
    @Test
    void testDeleteThesisById_Successful() {
        // Arrange
        long thesisId = 1L;
        when(thesisRepository.existsById(thesisId)).thenReturn(true);

        // Act
        thesisService.deleteThesisById(thesisId);

        // Assert
        verify(thesisRepository, times(1)).deleteById(thesisId);
    }

    // --------------------------------------------
    // 6. Test: Delete Thesis - Not Found
    // --------------------------------------------
    @Test
    void testDeleteThesisById_NotFound() {
        // Arrange
        long thesisId = 1L;
        when(thesisRepository.existsById(thesisId)).thenReturn(false);

        // Act & Assert
        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> thesisService.deleteThesisById(thesisId));
        assertEquals("Thesis not found with id: " + thesisId, exception.getMessage());
        verify(thesisRepository, never()).deleteById(thesisId);
    }

    // --------------------------------------------
    // 7. Test: Find Thesis by ID - Success
    // --------------------------------------------
    @Test
    void testFindThesisById_Success() {
        // Arrange
        long thesisId = 1L;
        Thesis thesis = new Thesis();
        thesis.setId(thesisId);
        thesis.setName("Sample Thesis");

        when(thesisRepository.findById(thesisId)).thenReturn(Optional.of(thesis));

        // Act
        Optional<Thesis> result = thesisService.findThesisById(thesisId);

        // Assert
        assertTrue(result.isPresent());
        assertEquals("Sample Thesis", result.get().getName());
        verify(thesisRepository, times(1)).findById(thesisId);
    }

    // --------------------------------------------
    // 8. Test: Find Thesis by ID - Not Found
    // --------------------------------------------
    @Test
    void testFindThesisById_NotFound() {
        // Arrange
        long thesisId = 1L;
        when(thesisRepository.findById(thesisId)).thenReturn(Optional.empty());

        // Act
        Optional<Thesis> result = thesisService.findThesisById(thesisId);

        // Assert
        assertFalse(result.isPresent());
        verify(thesisRepository, times(1)).findById(thesisId);
    }

    // --------------------------------------------
    // 9. Test: Find All Theses
    // --------------------------------------------
    @Test
    void testFindAllThesis() {
        // Arrange
        List<Thesis> theses = List.of(new Thesis(1L, "Thesis 1", "Text 1", LocalDate.now(), null, null, null),
                new Thesis(2L, "Thesis 2", "Text 2", LocalDate.now(), null, null, null));
        when(thesisRepository.findAll()).thenReturn(theses);

        // Act
        List<Thesis> result = thesisService.findAllTheses();

        // Assert
        assertEquals(2, result.size());
        assertEquals("Thesis 1", result.get(0).getName());
        assertEquals("Thesis 2", result.get(1).getName());
        verify(thesisRepository, times(1)).findAll();
    }
}
