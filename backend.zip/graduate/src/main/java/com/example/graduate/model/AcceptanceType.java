package com.example.graduate.model;

public enum AcceptanceType {
    UNDEFINED, ACCEPTED, DENIED
}
