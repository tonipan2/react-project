package com.example.graduate.repository;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.Thesis;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface ThesisRepository extends JpaRepository<Thesis, Long> {
    boolean existsById(long thesisId);

    @Query("SELECT t FROM Thesis t " +
            "JOIN t.application a " +
            "JOIN a.teacher teacher " +
            "WHERE teacher IN :teachers " +
            "AND EXISTS (" +
            "   SELECT td FROM ThesisDefending td " +
            "   WHERE td.thesis.id = t.id AND td.grade BETWEEN :minGrade AND :maxGrade" +
            ")")
    List<Thesis> findThesesByTeachersAndGradeRange(
            @Param("teachers") Set<Teacher> teachers,
            @Param("minGrade") String minGrade,
            @Param("maxGrade") String maxGrade);

}
