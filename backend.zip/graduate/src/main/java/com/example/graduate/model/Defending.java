package com.example.graduate.model;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "defending")
@Entity
public class Defending {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "defending_id")
    long id;

    @NotNull(message = "Date of defending cannot be null")
    @Column(name = "date_defending", nullable = false)
    LocalDate dateDefending;

    @OneToMany(mappedBy = "defending", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("defending-thesis-reference")
    Set<ThesisDefending> thesisDefendings;


    @JsonIgnore
    @ManyToMany(mappedBy = "defendings", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    Set<Teacher> teachers;
}
