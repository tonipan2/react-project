package com.example.graduate.repository;

import com.example.graduate.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    boolean existsById(long studentId);

    Optional<Student> findByUser(User user);

    @Query("SELECT t FROM Thesis t JOIN t.application a WHERE a.student.id = :studentId")
    List<Thesis> findThesesByStudentId(@Param("studentId") long studentId);

    @Query("SELECT a FROM Application a WHERE a.student.id = :studentId")
    List<Application> findApplicationsByStudentId(@Param("studentId") long studentId);

    @Query("SELECT td FROM ThesisDefending td " +
            "JOIN td.thesis t " +
            "JOIN t.application a " +
            "WHERE a.student.id = :studentId")
    List<ThesisDefending> findThesisDefendingsByStudent(@Param("studentId") long studentId);

}
