package com.example.graduate.service;

import com.example.graduate.dto.ReviewDTO;
import com.example.graduate.model.Review;
import com.example.graduate.model.Student;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.Thesis;
import com.example.graduate.repository.ReviewRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service

public class ReviewService {
    private final ReviewRepository reviewRepo;

    private final ThesisRepository thesisRepo;

    private final TeacherRepository teacherRepo;


    @Autowired
    public ReviewService(ReviewRepository reviewRepo, ThesisRepository thesisRepo, TeacherRepository teacherRepo) {
        this.reviewRepo = reviewRepo;
        this.thesisRepo = thesisRepo;
        this.teacherRepo = teacherRepo;
    }
    /**
     * Saves a new {@link Review} based on the provided {@link ReviewDTO}.
     *
     * @param reviewDTO the data transfer object representing the new review.
     */

    public Review saveReview(ReviewDTO reviewDTO){
        Review reviewToSave = new Review();

        reviewToSave.setText(reviewDTO.getText());
        reviewToSave.setDateUploaded(LocalDate.now());
        reviewToSave.setConclusion(reviewDTO.getConclusion());

        Thesis thesis = thesisRepo.findById(reviewDTO.getThesisId())
                .orElseThrow(() -> new RuntimeException("Thesis not found with ID: " + reviewDTO.getThesisId()));
        Teacher teacher = teacherRepo.findById(reviewDTO.getTeacherId())
                .orElseThrow(() -> new RuntimeException("Teacher not found with ID: " + reviewDTO.getTeacherId()));

        reviewToSave.setThesis(thesis);
        reviewToSave.setTeacher(teacher);

        return reviewRepo.save(reviewToSave);
    }
    /**
     * Updates an existing {@link Review} identified by its ID.
     *
     * @param reviewId      the ID of the student to update.
     * @param updatedReview the updated data transfer object for the review.
     */
    public Review updateReviewById(long reviewId, ReviewDTO updatedReview) {

        Review reviewToUpdate = findReviewById(reviewId)
                .orElseThrow(() -> new EntityNotFoundException("Review not found with id: " + reviewId));


        reviewToUpdate.setText(updatedReview.getText());
        reviewToUpdate.setDateUploaded(LocalDate.now());
        reviewToUpdate.setConclusion(updatedReview.getConclusion());

        Thesis thesis = thesisRepo.findById(updatedReview.getThesisId())
                .orElseThrow(() -> new RuntimeException("Thesis not found with ID: " + updatedReview.getThesisId()));
        Teacher teacher = teacherRepo.findById(updatedReview.getTeacherId())
                .orElseThrow(() -> new RuntimeException("Teacher not found with ID: " + updatedReview.getTeacherId()));

        reviewToUpdate.setThesis(thesis);
        reviewToUpdate.setTeacher(teacher);

        return reviewRepo.save(reviewToUpdate);
    }

    /**
     * Deletes an existing {@link Review} identified by its ID.
     *
     * @param id the ID of the review to delete.
     * @throws EntityNotFoundException if the review with the specified ID is not found.
     */
    public void deleteReviewById(long id) {
        if (!doesReviewExist(id)){
            throw new EntityNotFoundException("Review not found with id: " + id);
        }
        reviewRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Review} identified by its ID.
     *
     * @param id the ID of the review to retrieve.
     * @return the review with the specified ID.
     * @throws EntityNotFoundException if the review with the specified ID is not found.
     */
    public Optional<Review> findReviewById(long id) {
        return reviewRepo.findById(id);
    }

    /**
     * Retrieves all existing {@link Review} entities.
     *
     * @return a list of all review.
     */
    public List<Review> findAllReviews() {
        return reviewRepo.findAll();
    }

    /**
     * Checks if a review with the specified ID exists.
     *
     * @param id the ID of the review to check.
     * @return {@code true} if the review exists, {@code false} otherwise.
     */
    public boolean doesReviewExist(long id) {
        return reviewRepo.existsById(id);
    }

    public Review getReviewByThesisId(Long thesisId) {
        return reviewRepo.findByThesisId(thesisId);
    }

    public long countStudentsWithNegativeReviews() {
        return reviewRepo.countStudentsWithNegativeReviews();
    }

}
