package com.example.graduate.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "theses_have_defendings")
@Entity
public class ThesisDefending {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "thesis_defending_id")
    long id;

    @ManyToOne
    @JoinColumn(name = "thesis_id", nullable = false)
    @JsonBackReference("thesis-defending-reference") // Use the same unique reference name
    Thesis thesis;

    @ManyToOne
    @JoinColumn(name = "defending_id", nullable = false)
    @JsonBackReference("defending-thesis-reference")
    Defending defending;

    @Column(name = "grade", nullable = true)
    String grade;
}
