package com.example.graduate.service;

import com.example.graduate.dto.ThesisDTO;
import com.example.graduate.model.Application;
import com.example.graduate.model.Teacher;
import com.example.graduate.model.Thesis;
import com.example.graduate.repository.ApplicationRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service

public class ThesisService {
    private final ThesisRepository thesisRepo;

    private final ApplicationRepository applicationRepo;
    private final TeacherRepository teacherRepo;

    @Autowired
    public ThesisService(ThesisRepository thesisRepo, ApplicationRepository applicationRepo, TeacherRepository teacherRepo) {
        this.thesisRepo = thesisRepo;
        this.applicationRepo = applicationRepo;
        this.teacherRepo = teacherRepo;
    }
    /**
     * Saves a new {@link Thesis} based on the provided {@link ThesisDTO}.
     *
     * @param thesisDTO the data transfer object representing the new thesis.
     */

    public Thesis saveThesis(ThesisDTO thesisDTO){
        Thesis thesisToSave = new Thesis();
        thesisToSave.setId(thesisDTO.getId());
        thesisToSave.setName(thesisDTO.getName());
        thesisToSave.setText(thesisDTO.getText());
        thesisToSave.setDateUploaded(LocalDate.now());
        Optional<Application> applicationOptional = applicationRepo.findById(thesisDTO.getApplicationId());
        if (applicationOptional.isEmpty()) {
            throw new EntityNotFoundException("Application not found for ID: " + thesisDTO.getApplicationId());
        }
        applicationOptional.ifPresent(thesisToSave::setApplication);
    thesisRepo.save(thesisToSave);
        return thesisToSave;
    }
    /**
     * Updates an existing {@link Thesis} identified by its ID.
     *
     * @param thesisId      the ID of the student to update.
     * @param updatedThesis the updated data transfer object for the thesis.
     */
    public Thesis updateThesisById(Long thesisId, ThesisDTO thesisDTO) {
        // Check if the application exists
        Application application = applicationRepo.findById(thesisDTO.getApplicationId())
                .orElseThrow(() -> new EntityNotFoundException("Application not found for ID: " + thesisDTO.getApplicationId()));

        // Find the thesis to update
        Thesis thesis = thesisRepo.findById(thesisId)
                .orElseThrow(() -> new EntityNotFoundException("Thesis not found for ID: " + thesisId));

        // Update thesis fields
        thesis.setName(thesisDTO.getName());
        thesis.setText(thesisDTO.getText());
        thesis.setApplication(application);  // Set the correct application

        // Save the updated thesis
        return thesisRepo.save(thesis);
    }


    /**
     * Deletes an existing {@link Thesis} identified by its ID.
     *
     * @param id the ID of the thesis to delete.
     * @throws EntityNotFoundException if the thesis with the specified ID is not found.
     */
    public void deleteThesisById(long id) {
        if (!doesThesisExist(id)){
            throw new EntityNotFoundException("Thesis not found with id: " + id);
        }
        thesisRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Thesis} identified by its ID.
     *
     * @param id the ID of the thesis to retrieve.
     * @return the thesis with the specified ID.
     * @throws EntityNotFoundException if the thesis with the specified ID is not found.
     */
    public Optional<Thesis> findThesisById(long id) {
        return thesisRepo.findById(id);
    }

    /**
     * Retrieves all existing {@link Thesis} entities.
     *
     * @return a list of all thesis.
     */
    public List<Thesis> findAllTheses() {
        return thesisRepo.findAll();
    }

    /**
     * Checks if a thesis with the specified ID exists.
     *
     * @param id the ID of the thesis to check.
     * @return {@code true} if the thesis exists, {@code false} otherwise.
     */
    public boolean doesThesisExist(long id) {
        return thesisRepo.existsById(id);
    }

    public List<Thesis> getThesesByGradeRange(String minGrade, String maxGrade, long teacherId) {
        // Validate that the user is a teacher
        Teacher teacher = teacherRepo.findById(teacherId)
                .orElseThrow(() -> new IllegalArgumentException("Teacher not found"));

        // Fetch all teachers in the same departments as the requesting teacher
        Set<Teacher> departmentTeachers = teacherRepo.findAllByDepartments(teacher.getDepartments());

        // Use the repository method to fetch theses
        return thesisRepo.findThesesByTeachersAndGradeRange(departmentTeachers, minGrade, maxGrade);
    }

}
