package com.example.graduate.dto;

import com.example.graduate.model.Defending;
import com.example.graduate.model.Thesis;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ThesisDefendingDTO {
    long id;
    long thesisId;
    long defendingId;
    String grade;
}
