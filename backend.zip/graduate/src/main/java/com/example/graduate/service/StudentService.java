package com.example.graduate.service;

import com.example.graduate.dto.StudentDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.DepartmentRepository;
import com.example.graduate.repository.StudentRepository;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service

public class StudentService {
    private final StudentRepository studentRepo;
    @Autowired
    private final UserService userService;
    @Autowired
    private final DepartmentService departmentService;
    private final DepartmentRepository departmentRepo;


    @Autowired
    public StudentService(StudentRepository studentRepo, UserService userService, DepartmentService departmentService, DepartmentRepository departmentRepo) {
        this.studentRepo = studentRepo;
        this.userService = userService;
        this.departmentService = departmentService;
        this.departmentRepo = departmentRepo;
    }
    /**
     * Saves a new {@link Student} based on the provided {@link StudentDTO}.
     *
     * @param studentDTO the data transfer object representing the new student.
     */
    public Student saveStudent(StudentDTO studentDTO) {
        User user = userService.findUserById(studentDTO.getUserId()); // Corrected to use userId
        validateRoleIsStudent(user);

        Student studentToSave = new Student();
        studentToSave.setUser(user);

        studentToSave.setId(studentDTO.getId());
        studentToSave.setFacultyNumber(studentDTO.getFacultyNumber());

        Set<Department> departments = new HashSet<>(departmentRepo.findAllById(studentDTO.getDepartmentIds()));
        studentToSave.setDepartments(departments);

        for (Department department : departments) {
            department.getStudents().add(studentToSave);
        }

        return studentRepo.save(studentToSave);
    }
    /**
     * Updates an existing {@link Student} identified by its ID.
     *
     * @param studentId      the ID of the student to update.
     * @param updatedStudent the updated data transfer object for the student.
     */
    public Student updateStudentById(long studentId, StudentDTO updatedStudent) {
        // Ensure the user ID is valid
        if (updatedStudent.getUserId() <= 0) {
            throw new IllegalArgumentException("Invalid user ID: " + updatedStudent.getUserId());
        }

        // Find the User entity
        User newUser = userService.findUserById(updatedStudent.getUserId());
        validateRoleIsStudent(newUser);

        // Fetch the Student entity and handle the Optional
        Student studentToUpdate = findStudentById(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with id: " + studentId));

        // Only update the user if it's different from the current one
        User currentUser = studentToUpdate.getUser();
        if (currentUser == null || currentUser.getId() != newUser.getId()) {
            studentToUpdate.setUser(newUser);
        }

        // Update other fields if necessary
        Set<Department> departments = new HashSet<>(departmentRepo.findAllById(updatedStudent.getDepartmentIds()));
        studentToUpdate.setDepartments(departments);

        for (Department department : departments) {
            department.getStudents().add(studentToUpdate);
        }

        studentToUpdate.setFacultyNumber(updatedStudent.getFacultyNumber());

        return studentRepo.save(studentToUpdate);
    }


    /**
     * Validates that the account role is "student".
     *
     * @param user the account to validate.
     * @throws IllegalArgumentException if the account role is not "student".
     */
    public void validateRoleIsStudent(User user) {
        boolean isStudent = user.getAuthorities().stream()
                .anyMatch(role -> role.getAuthority().equals("ROLE_STUDENT"));
        if (!isStudent) {
            throw new IllegalArgumentException("Role must be student to assign account to a student");
        }
    }


    /**
     * Deletes an existing {@link Student} identified by its ID.
     *
     * @param id the ID of the student to delete.
     * @throws EntityNotFoundException if the student with the specified ID is not found.
     */
    public void deleteStudentById(long id) {
        if (!doesStudentExist(id)){
            throw new EntityNotFoundException("Student not found with id: " + id);
        }
        studentRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Student} identified by its ID.
     *
     * @param id the ID of the student to retrieve.
     * @return the student with the specified ID.
     * @throws EntityNotFoundException if the student with the specified ID is not found.
     */
    public Optional<Student> findStudentById(long id) {
        return studentRepo.findById(id);
    }

    /**
     * Retrieves all existing {@link Student} entities.
     *
     * @return a list of all students.
     */
    public List<Student> findAllStudents() {
        return studentRepo.findAll();
    }

    /**
     * Checks if a student with the specified ID exists.
     *
     * @param id the ID of the student to check.
     * @return {@code true} if the student exists, {@code false} otherwise.
     */
    public boolean doesStudentExist(long id) {
        return studentRepo.existsById(id);
    }

    public List<Application> getStudentApplications(long id) {
        List<Application> applications = studentRepo.findApplicationsByStudentId(id);
        if (applications.isEmpty()) {
            throw new EntityNotFoundException("No applications found for Student with ID " + id);
        }
        return applications;
    }

    public Student findStudentByUsername(String username) {
        User user = userService.findUserByUsername(username);
        validateRoleIsStudent(user);

        return studentRepo.findByUser(user)
                .orElseThrow(() -> new EntityNotFoundException("Student not found for username: " + username));
    }

    public List<Thesis> getThesesByStudentId(long studentId) {
        return studentRepo.findThesesByStudentId(studentId);
    }

    public List<ThesisDefending> getThesisDefendingsForStudent(long studentId) {
        return studentRepo.findThesisDefendingsByStudent(studentId);
    }

}
