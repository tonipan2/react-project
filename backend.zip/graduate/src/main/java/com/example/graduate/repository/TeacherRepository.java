package com.example.graduate.repository;

import com.example.graduate.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Long> {
    boolean existsById(long teacherId);

    Optional<Teacher> findByUser(User user);

    @Query("SELECT a FROM Application a " +
            "JOIN a.teacher t " +
            "JOIN t.departments d " +
            "WHERE d IN :departments")
    List<Application> findApplicationsByDepartments(@Param("departments") Set<Department> departments);

    @Query("SELECT t FROM Teacher t JOIN t.departments d WHERE d IN :departments")
    Set<Teacher> findAllByDepartments(@Param("departments") Set<Department> departments);

    @Query("SELECT d FROM Defending d JOIN d.teachers t WHERE t.id = :teacherId")
    List<Defending> findDefendingsByTeacher(@Param("teacherId") Long teacherId);


}
