package com.example.graduate.repository;

import com.example.graduate.model.Student;
import com.example.graduate.model.ThesisDefending;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ThesisDefendingRepository extends JpaRepository<ThesisDefending, Long> {

    @Query("SELECT td FROM ThesisDefending td " +
            "JOIN td.defending d " +
            "JOIN td.thesis t " +
            "JOIN t.application a " +
            "WHERE d.dateDefending BETWEEN :startDate AND :endDate " +
            "AND CAST(td.grade AS int) > 2")
    List<ThesisDefending> findThesisDefendingsWithGradeGreaterThanAndDateRange(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT DISTINCT td.thesis.application.student FROM ThesisDefending td " +
            "JOIN td.thesis t " +
            "JOIN t.application a " +
            "JOIN a.teacher te " +
            "WHERE td.grade != '2' AND te.id = :teacherId")
    List<Student> findGraduatedStudents(@Param("teacherId") long teacherId);

}


