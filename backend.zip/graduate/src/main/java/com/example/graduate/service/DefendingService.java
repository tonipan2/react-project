package com.example.graduate.service;

import com.example.graduate.dto.DefendingDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.DefendingRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service

public class DefendingService {
    private final DefendingRepository defendingRepo;

    private final TeacherRepository teacherRepo;
    @Autowired
    private final TeacherService teacherService;

    private final ThesisRepository thesisRepo;


    @Autowired
    public DefendingService(DefendingRepository defendingRepo, TeacherRepository teacherRepo, TeacherService teacherService, ThesisRepository thesisRepo) {
        this.defendingRepo = defendingRepo;
        this.teacherRepo = teacherRepo;
        this.teacherService = teacherService;
        this.thesisRepo = thesisRepo;
    }
    /**
     * Saves a new {@link Defending} based on the provided {@link DefendingDTO}.
     *
     * @param defendingDTO the data transfer object representing the new defending.
     */

    public Defending saveDefending(DefendingDTO defendingDTO, Long teacherId) {


        Set<Teacher> teachersInDepartments = teacherService.findAllByDepartment(teacherId);

        // Create the defending and set its attributes
        Defending defendingToSave = new Defending();
        defendingToSave.setDateDefending(defendingDTO.getDateDefending());

        for (Teacher teacher : teachersInDepartments) {
            teacher.getDefendings().add(defendingToSave); // Ensure the relationship is maintained on both sides
        }

        defendingToSave.setTeachers(teachersInDepartments);

        // Save the defending
        return defendingRepo.save(defendingToSave);
    }

    /**
     * Updates an existing {@link Defending} identified by its ID.
     *
     * @param defendingId      the ID of the student to update.
     * @param updatedDefending the updated data transfer object for the defending.
     */
    public Defending updateDefendingById(long defendingId, DefendingDTO updatedDefending) {

        Defending defendingToUpdate = findDefendingById(defendingId)
                .orElseThrow(() -> new EntityNotFoundException("Defending not found with id: " + defendingId));

        Set<Teacher> teachers = new HashSet<>(teacherRepo.findAllById(updatedDefending.getTeacherIds()));
        defendingToUpdate.setTeachers(teachers);

        for (Teacher teacher : teachers){
            teacher.getDefendings().add(defendingToUpdate);
        }

        return defendingRepo.save(defendingToUpdate);
    }

    /**
     * Deletes an existing {@link Defending} identified by its ID.
     *
     * @param id the ID of the defending to delete.
     * @throws EntityNotFoundException if the defending with the specified ID is not found.
     */
    public void deleteDefendingById(long id) {
        if (!doesDefendingExist(id)){
            throw new EntityNotFoundException("Defending not found with id: " + id);
        }
        defendingRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Defending} identified by its ID.
     *
     * @param id the ID of the defending to retrieve.
     * @return the defending with the specified ID.
     * @throws EntityNotFoundException if the defending with the specified ID is not found.
     */
    public Optional<Defending> findDefendingById(long id) {
        return defendingRepo.findById(id);
    }

    /**
     * Retrieves all existing {@link Defending} entities.
     *
     * @return a list of all defending.
     */
    public List<Defending> findAllDefendings() {
        return defendingRepo.findAll();
    }

    /**
     * Checks if a defending with the specified ID exists.
     *
     * @param id the ID of the defending to check.
     * @return {@code true} if the defending exists, {@code false} otherwise.
     */
    public boolean doesDefendingExist(long id) {
        return defendingRepo.existsById(id);
    }

    public double calculateAverageStudentsInPeriod(LocalDate startDate, LocalDate endDate) {
        // Fetch defendings within the date range
        List<Defending> defendings = defendingRepo.findDefendingsWithinPeriod(startDate, endDate);

        // Create a set to store unique students
        Set<Student> students = new HashSet<>();

        // Iterate through defendings and collect students
        for (Defending defending : defendings) {
            for (ThesisDefending thesisDefending : defending.getThesisDefendings()) {
                Thesis thesis = thesisDefending.getThesis();
                Application application = thesis.getApplication();
                Student student = application.getStudent();
                students.add(student);  // Add student to the set to ensure uniqueness
            }
        }

        // Calculate the average number of students
        return students.size();
    }

}
