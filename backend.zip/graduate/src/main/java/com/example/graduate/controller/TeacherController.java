package com.example.graduate.controller;

import com.example.graduate.dto.TeacherDTO;
import com.example.graduate.model.*;
import com.example.graduate.service.*;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/teacher")
public class TeacherController {
    private final TeacherService teacherService;
    @Autowired
    TeacherController(TeacherService teacherService){
        this.teacherService = teacherService;
    }
    @Autowired
    private StudentService studentService;

    @PostMapping("/add")
    public ResponseEntity<Teacher> postTeacher(@RequestBody TeacherDTO teacherDTO){
        Teacher teacher = teacherService.saveTeacher(teacherDTO);
        return ResponseEntity.ok(teacher);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Teacher> patchTeacher(@PathVariable Long id, @RequestBody TeacherDTO teacherDTO){
        Teacher teacher = teacherService.updateTeacherById(id, teacherDTO);
        return ResponseEntity.ok(teacher);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTeacher(@PathVariable Long id){
        try{
            teacherService.deleteTeacherById(id);
            return ResponseEntity.ok("The Teacher has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Teacher>> fetchAll(){
        List<Teacher> teachers= teacherService.findAllTeachers();
        return ResponseEntity.ok(teachers);
    }

    @GetMapping("/fetch/{id}")
    public ResponseEntity<Teacher> fetchById(@PathVariable long id){
        Teacher teacher = teacherService.findTeacherById(id);
        return ResponseEntity.ok(teacher);
    }

    @GetMapping("/fetchByUsername/{username}")
    public ResponseEntity<Teacher> fetchByUserId(@PathVariable String username){
        Teacher teacher = teacherService.findTeacherByUsername(username);
        return ResponseEntity.ok(teacher);
    }

    @GetMapping("/fetchApplications/{id}")
    public ResponseEntity<List<Application>> fetchApplications(@PathVariable long id){
        List<Application> applications = teacherService.findTeacherApplications(id);
        return ResponseEntity.ok(applications);
    }

    @GetMapping("/fetchDefendings/{teacherId}")
    public ResponseEntity<List<Defending>> getDefendingsForTeacher(@PathVariable Long teacherId) {
        List<Defending> defendings = teacherService.getDefendingsForTeacher(teacherId);
        return ResponseEntity.ok(defendings);
    }

    @GetMapping("/fetchTeachersInDepartment/{teacherId}")
    public ResponseEntity<Set<Teacher>> fetchTeachersInDepartment(@PathVariable long teacherId){
        Set<Teacher> teachers = teacherService.findAllByDepartment(teacherId);
        return ResponseEntity.ok(teachers);
    }
}
