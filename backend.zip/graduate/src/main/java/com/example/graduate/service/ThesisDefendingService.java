package com.example.graduate.service;

import com.example.graduate.dto.ThesisDefendingDTO;
import com.example.graduate.model.Defending;
import com.example.graduate.model.Student;
import com.example.graduate.model.Thesis;
import com.example.graduate.model.ThesisDefending;
import com.example.graduate.repository.DefendingRepository;
import com.example.graduate.repository.ThesisDefendingRepository;
import com.example.graduate.repository.ThesisRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service

public class ThesisDefendingService {

    private final ThesisDefendingRepository thesisDefendingRepository;
    private final DefendingRepository defendingRepo;
    private final ThesisRepository thesisRepo;

    @Autowired
    public ThesisDefendingService(ThesisDefendingRepository thesisDefendingRepository, DefendingRepository defendingRepo, ThesisRepository thesisRepo)
    {
        this.thesisDefendingRepository = thesisDefendingRepository;
        this.defendingRepo = defendingRepo;
        this.thesisRepo = thesisRepo;
    }

    public ThesisDefending saveThesisDefending(ThesisDefendingDTO thesisDefendingDTO) {
        ThesisDefending thesisDefendingToSave = new ThesisDefending();

        // Fetch Thesis and Defending by their IDs
        Thesis thesis = thesisRepo.findById(thesisDefendingDTO.getThesisId())
                .orElseThrow(() -> new EntityNotFoundException("Thesis not found with id: " + thesisDefendingDTO.getThesisId()));

        Defending defending = defendingRepo.findById(thesisDefendingDTO.getDefendingId())
                .orElseThrow(() -> new EntityNotFoundException("Defending not found with id: " + thesisDefendingDTO.getDefendingId()));

        thesisDefendingToSave.setThesis(thesis);
        thesisDefendingToSave.setDefending(defending);


        return thesisDefendingRepository.save(thesisDefendingToSave);
    }




    public ThesisDefending updateThesisDefending(long thesisDefendingId, ThesisDefendingDTO updatedThesisDefendingDTO){

        ThesisDefending thesisDefendingToUpdate = findThesisDefendingById(thesisDefendingId)
                .orElseThrow(() -> new EntityNotFoundException("Thesis not found with id: " + thesisDefendingId));

        //thesisDefendingToUpdate.setDefending(updatedThesisDefendingDTO.getDefendingId());
        //thesisDefendingToUpdate.setThesis(updatedThesisDefendingDTO.getThesisId());
        thesisDefendingToUpdate.setGrade(updatedThesisDefendingDTO.getGrade());
        return thesisDefendingRepository.save(thesisDefendingToUpdate);
    }

    public void deleteThesisDefendingById(long id) {
        if (!doesThesisDefendingExist(id)){
            throw new EntityNotFoundException("Thesis not found with id: " + id);
        }
        thesisDefendingRepository.deleteById(id);
    }

    public Optional<ThesisDefending> findThesisDefendingById(long id) {
        return thesisDefendingRepository.findById(id);
    }

    public List<ThesisDefending> findAllThesesDefendings() {
        return thesisDefendingRepository.findAll();
    }

    public boolean doesThesisDefendingExist(long id) {
        return thesisDefendingRepository.existsById(id);
    }

    public List<Student> getStudentsWithThesisDefendingInPeriodAndGrade(
            LocalDate startDate, LocalDate endDate) {
        List<ThesisDefending> thesisDefendings = thesisDefendingRepository
                .findThesisDefendingsWithGradeGreaterThanAndDateRange(startDate, endDate);

        return thesisDefendings.stream()
                .map(td -> td.getThesis().getApplication().getStudent())
                .distinct() // Ensure no duplicate students
                .collect(Collectors.toList());
    }

    public long getGraduatedStudents(long teacherId) {
        List<Student> students = thesisDefendingRepository.findGraduatedStudents(teacherId);
        return students.size();  // Return the number of students
    }
}

