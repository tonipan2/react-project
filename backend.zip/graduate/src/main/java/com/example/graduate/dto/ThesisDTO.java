package com.example.graduate.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.cglib.core.Local;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ThesisDTO {
    long id;
    String name;
    String text;
    LocalDate dateUploaded;
    long applicationId;

    public <E> ThesisDTO(long l, String thesisTitle, String thesisText, Object o, Set<E> of, long l1, Set<E> of1) {
    }
    public ThesisDTO(long id, String name, String text, LocalDate dateUploaded, Set<Object> someSet, long applicationId, Set<Object> anotherSet) {
        this.id = id;
        this.name = name;
        this.text = text;
        this.dateUploaded = dateUploaded;
        this.applicationId = applicationId;  // Set the applicationId correctly
    }

}