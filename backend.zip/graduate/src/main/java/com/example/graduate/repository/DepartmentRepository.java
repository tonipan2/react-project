package com.example.graduate.repository;
import com.example.graduate.model.Department;
import com.example.graduate.model.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    boolean existsById(long departmentId);

    @Query("SELECT t FROM Teacher t JOIN t.departments d WHERE d IN :departments")
    Set<Teacher> findTeachersByDepartments(Set<Department> departments);


}
