package com.example.graduate.service;

import com.example.graduate.dto.ApplicationDTO;
import com.example.graduate.model.*;
import com.example.graduate.repository.ApplicationRepository;
import com.example.graduate.repository.StudentRepository;
import com.example.graduate.repository.TeacherRepository;
import com.example.graduate.repository.ThesisRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service

public class ApplicationService {
    private final ApplicationRepository applicationRepo;

    private final StudentRepository studentRepo;

    private final TeacherRepository teacherRepo;

    private final ThesisRepository thesisRepo;

    @Autowired
    private final StudentService studentService;

    @Autowired
    private final TeacherService teacherService;

    @Autowired
    public ApplicationService(ApplicationRepository applicationRepo, StudentRepository studentRepo, TeacherRepository teacherRepo, ThesisRepository thesisRepo, StudentService studentService, TeacherService teacherService) {
        this.applicationRepo = applicationRepo;
        this.studentRepo = studentRepo;
        this.teacherRepo = teacherRepo;
        this.thesisRepo = thesisRepo;
        this.studentService = studentService;
        this.teacherService = teacherService;
    }
    /**
     * Saves a new {@link Application} based on the provided {@link ApplicationDTO}.
     *
     * @param applicationDTO the data transfer object representing the new application.
     */

    public Application saveApplication(ApplicationDTO applicationDTO){
        Application applicationToSave = new Application();

        applicationToSave.setTheme(applicationDTO.getTheme());
        applicationToSave.setAim(applicationDTO.getAim());
        applicationToSave.setTasks(applicationDTO.getTasks());
        applicationToSave.setTechnologies(applicationDTO.getTechnologies());

        // Default value for acceptanceType if null
        applicationToSave.setAcceptanceType(
                applicationDTO.getAcceptanceType() != null ? applicationDTO.getAcceptanceType() : AcceptanceType.UNDEFINED
        );

        Student student = studentRepo.findById(applicationDTO.getStudentId())
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + applicationDTO.getStudentId()));
        Teacher teacher = teacherRepo.findById(applicationDTO.getTeacherId())
                .orElseThrow(() -> new RuntimeException("Teacher not found with ID: " + applicationDTO.getTeacherId()));

        applicationToSave.setStudent(student);
        applicationToSave.setTeacher(teacher);

        return applicationRepo.save(applicationToSave);
    }
    /**
     * Updates an existing {@link Application} identified by its ID.
     *
     * @param applicationId      the ID of the student to update.
     * @param updatedApplication the updated data transfer object for the application.
     */
    public Application updateApplicationById(long applicationId, ApplicationDTO updatedApplication) {

        Application applicationToUpdate = findApplicationById(applicationId)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + applicationId));

        /*
        // Manually checking for null instead of using Optional
        Optional<Student> student = studentService.findStudentById(updatedApplication.getStudentId());
        if (student.isEmpty()) {
            throw new EntityNotFoundException("Student not found with id: " + updatedApplication.getStudentId());
        }
        applicationToUpdate.setStudent(student.get());

        Teacher teacher = teacherService.findTeacherById(updatedApplication.getTeacherId());
        if (teacher == null) {
            throw new EntityNotFoundException("Teacher not found with id: " + updatedApplication.getTeacherId());
        }
        applicationToUpdate.setTeacher(teacher);*/

        // Update other fields if needed
        applicationToUpdate.setTheme(updatedApplication.getTheme());
        applicationToUpdate.setAim(updatedApplication.getAim());
        applicationToUpdate.setTasks(updatedApplication.getTasks());
        applicationToUpdate.setTechnologies(updatedApplication.getTechnologies());
        applicationToUpdate.setAcceptanceType(updatedApplication.getAcceptanceType());

        return applicationRepo.save(applicationToUpdate);
    }

    /**
     * Deletes an existing {@link Application} identified by its ID.
     *
     * @param id the ID of the application to delete.
     * @throws EntityNotFoundException if the application with the specified ID is not found.
     */
    public void deleteApplicationById(long id) {
        if (!doesApplicationExist(id)){
            throw new EntityNotFoundException("Application not found with id: " + id);
        }
        applicationRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Application} identified by its ID.
     *
     * @param id the ID of the application to retrieve.
     * @return the application with the specified ID.
     * @throws EntityNotFoundException if the application with the specified ID is not found.
     */
    public Optional<Application> findApplicationById(long id) {
        return applicationRepo.findById(id);
    }

    /**
     * Retrieves all existing {@link Application} entities.
     *
     * @return a list of all application.
     */
    public List<Application> findAllApplications() {
        return applicationRepo.findAll();
    }

    /**
     * Checks if a application with the specified ID exists.
     *
     * @param id the ID of the application to check.
     * @return {@code true} if the application exists, {@code false} otherwise.
     */
    public boolean doesApplicationExist(long id) {
        return applicationRepo.existsById(id);
    }


}
