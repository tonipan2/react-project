package com.example.graduate.controller;

import com.example.graduate.dto.ThesisDefendingDTO;
import com.example.graduate.model.Student;
import com.example.graduate.model.ThesisDefending;
import com.example.graduate.service.ThesisDefendingService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/thesis-defendings")
@RequiredArgsConstructor
public class ThesisDefendingController {

    private final ThesisDefendingService thesisDefendingService;

    @PostMapping("/add")
    public ResponseEntity<ThesisDefending> postThesisDefending(@RequestBody ThesisDefendingDTO thesisDefendingDTO){
        ThesisDefending thesisDefending = thesisDefendingService.saveThesisDefending(thesisDefendingDTO);
        return ResponseEntity.ok(thesisDefending);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<ThesisDefending> patchThesisDefending(@PathVariable Long id, @RequestBody ThesisDefendingDTO thesisDefendingDTO){
        ThesisDefending thesisDefending = thesisDefendingService.updateThesisDefending(id, thesisDefendingDTO);
        return ResponseEntity.ok(thesisDefending);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteThesisDefending(@PathVariable Long id){
        try{
            thesisDefendingService.deleteThesisDefendingById(id);
            return ResponseEntity.ok("The Thesis Defending has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<ThesisDefending>> fetchAll(){
        List<ThesisDefending> thesisDefendings= thesisDefendingService.findAllThesesDefendings();
        return ResponseEntity.ok(thesisDefendings);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<ThesisDefending> fetchById(@PathVariable long id) {
        ThesisDefending thesisDefending = thesisDefendingService.findThesisDefendingById(id)
                .orElseThrow(() -> new EntityNotFoundException("Thesis Defending not found with id: " + id));
        return ResponseEntity.ok(thesisDefending);
    }

    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudentsWithThesisDefendingInPeriodAndGrade(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        List<Student> students = thesisDefendingService
                .getStudentsWithThesisDefendingInPeriodAndGrade(startDate, endDate);
        return ResponseEntity.ok(students);
    }

    @GetMapping("/students-graduated")
    public ResponseEntity<Long> getNumberOfStudentsWithThesisDefendingAndGradeNotEqualToTwo(@RequestParam long teacherId) {
        long count = thesisDefendingService.getGraduatedStudents(teacherId);
        return ResponseEntity.ok(count);
    }
}
