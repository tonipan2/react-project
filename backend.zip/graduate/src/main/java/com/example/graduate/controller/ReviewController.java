package com.example.graduate.controller;

import com.example.graduate.dto.ReviewDTO;
import com.example.graduate.model.Review;
import com.example.graduate.service.ReviewService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/review")
public class ReviewController {
    private final ReviewService reviewService;
    @Autowired
    ReviewController(ReviewService reviewService){
        this.reviewService = reviewService;
    }

    @PostMapping("/add")
    public ResponseEntity<Review> postReview(@RequestBody ReviewDTO reviewDTO){
        Review review = reviewService.saveReview(reviewDTO);
        return ResponseEntity.ok(review);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Review> patchReview(@PathVariable Long id, @RequestBody ReviewDTO reviewDTO){
        Review review = reviewService.updateReviewById(id, reviewDTO);
        return ResponseEntity.ok(review);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteReview(@PathVariable Long id){
        try{
            reviewService.deleteReviewById(id);
            return ResponseEntity.ok("The Review has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Review>> fetchAll(){
        List<Review> reviews= reviewService.findAllReviews();
        return ResponseEntity.ok(reviews);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<Review> fetchById(@PathVariable long id) {
        Review review = reviewService.findReviewById(id)
                .orElseThrow(() -> new EntityNotFoundException("Review not found with id: " + id));
        return ResponseEntity.ok(review);
    }

    @GetMapping("/fetchByThesisId/{thesisId}")
    public ResponseEntity<?> fetchByThesisId(@PathVariable Long thesisId) {
        try {
            Review review = reviewService.getReviewByThesisId(thesisId);
            if (review != null) {
                return ResponseEntity.ok(review);
            } else {
                return ResponseEntity.status(404).body("No review found for the given thesis ID.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("An error occurred while fetching the review.");
        }
    }

    @GetMapping("/negative-review-count")
    public long getStudentsWithNegativeReviewsCount() {
        return reviewService.countStudentsWithNegativeReviews();
    }
}
