package com.example.graduate.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import lombok.experimental.FieldDefaults;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "department")
@Entity
public class Department {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "department_id")
        long id;

        //@NotNull(message = "Department cannot be null")
        //@NotBlank(message = "Department cannot be left blank")
        @Size(max = 20, message = "Department has to be with up to 20 characters")
        @Column(name = "departmentName", nullable = false)
        String departmentName;

        @JsonIgnore
        @ManyToMany(mappedBy = "departments")
        Set<Teacher> teachers;

        @JsonIgnore
        @ManyToMany(mappedBy = "departments")
        Set<Student> students;


        public Department(long l, String physics) {
        }
}
