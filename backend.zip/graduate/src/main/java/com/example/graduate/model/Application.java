package com.example.graduate.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;
import java.util.Set;

@SpringBootApplication
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "application")
@Entity
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "application_id")
    long id;

    @NotNull(message = "Theme cannot be null")
    @Column(name = "theme", nullable = false)
    String theme;

    @NotNull(message = "Aim cannot be null")
    @Column(name = "aim", nullable = false)
    String aim;

    @NotNull(message = "Tasks cannot be null")
    @Column(name = "tasks", nullable = false)
    String tasks;

    @NotNull(message = "Technologies cannot be null")
    @Column(name = "technologies", nullable = false)
    String technologies;

    @NotNull(message = "Student cannot be null")
    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    @JsonBackReference
    Student student;

    @NotNull(message = "Teacher cannot be null")
    @ManyToOne
    @JoinColumn(name = "teacher_id", nullable = false)
    @JsonManagedReference
    Teacher teacher;

    @NotNull(message = "Acceptance cannot be null")
    @Column(name = "acceptance", nullable = false)
    AcceptanceType acceptanceType;

    @JsonIgnore
    @OneToMany(mappedBy = "application", cascade = CascadeType.ALL)
    @JsonManagedReference
    Set<Thesis> theses;

    public Application(Long id, String theme) {
        this.id = id;
        this.theme = theme;
    }


    public Application(long l, String theme, String aim, String tasks, String technologies, AcceptanceType acceptanceType, Object o, Object o1) {
    }
}
