package com.example.graduate.controller;

import com.example.graduate.dto.DepartmentDTO;
import com.example.graduate.model.Department;
import com.example.graduate.service.DepartmentService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {
    private final DepartmentService departmentService;
    @Autowired
    DepartmentController(DepartmentService departmentService){
        this.departmentService = departmentService;
    }

    @PostMapping("/add")
    public ResponseEntity<Department> postDepartment(@RequestBody DepartmentDTO departmentDTO){
        Department department = departmentService.saveDepartment(departmentDTO);
        return ResponseEntity.ok(department);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Department> patchDepartment(@PathVariable Long id, @RequestBody DepartmentDTO departmentDTO){
        Department department = departmentService.updateDepartmentById(id, departmentDTO);
        return ResponseEntity.ok(department);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteDepartment(@PathVariable Long id){
        try{
            departmentService.deleteDepartmentById(id);
            return ResponseEntity.ok("The Department has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Department>> fetchAll(){
        List<Department> departments= departmentService.findAllDepartments();
        return ResponseEntity.ok(departments);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<Department> fetchById(@PathVariable long id) {
        Department department = departmentService.findDepartmentById(id)
                .orElseThrow(() -> new EntityNotFoundException("Department not found with id: " + id));
        return ResponseEntity.ok(department);
    }

}
