package com.example.graduate.controller;

import com.example.graduate.dto.DefendingDTO;
import com.example.graduate.model.Defending;
import com.example.graduate.service.DefendingService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/defending")
public class DefendingController {
    private final DefendingService defendingService;
    @Autowired
    DefendingController(DefendingService defendingService){
        this.defendingService = defendingService;
    }

    @PostMapping("/add")
    public ResponseEntity<Defending> addDefending(@RequestBody DefendingDTO defendingDTO,
                                                  @RequestParam Long teacherId) {
        try {
            // Save the defending with associated teachers
            Defending savedDefending = defendingService.saveDefending(defendingDTO, teacherId);

            return ResponseEntity.ok(savedDefending);
        } catch (Exception e) {
            // Handle exceptions and return appropriate response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Defending> patchDefending(@PathVariable Long id, @RequestBody DefendingDTO defendingDTO){
        Defending defending = defendingService.updateDefendingById(id, defendingDTO);
        return ResponseEntity.ok(defending);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteDefending(@PathVariable Long id){
        try{
            defendingService.deleteDefendingById(id);
            return ResponseEntity.ok("The Defending has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Defending>> fetchAll(){
        List<Defending> defendings= defendingService.findAllDefendings();
        return ResponseEntity.ok(defendings);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<Defending> fetchById(@PathVariable long id) {
        Defending defending = defendingService.findDefendingById(id)
                .orElseThrow(() -> new EntityNotFoundException("Defending not found with id: " + id));
        return ResponseEntity.ok(defending);
    }

    @GetMapping("/average-students")
    public ResponseEntity<Double> getAverageStudents(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        double averageStudents = defendingService.calculateAverageStudentsInPeriod(startDate, endDate);
        return ResponseEntity.ok(averageStudents);
    }



}
