package com.example.graduate.controller;

import com.example.graduate.dto.ThesisDTO;
import com.example.graduate.model.Thesis;
import com.example.graduate.service.ThesisService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/thesis")
public class ThesisController {
    private final ThesisService thesisService;
    @Autowired
    ThesisController(ThesisService thesisService){
        this.thesisService = thesisService;
    }

    @PostMapping("/add")
    public ResponseEntity<Thesis> postThesis(@RequestBody ThesisDTO thesisDTO){
        Thesis thesis = thesisService.saveThesis(thesisDTO);
        return ResponseEntity.ok(thesis);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Thesis> patchThesis(@PathVariable Long id, @RequestBody ThesisDTO thesisDTO){
        Thesis thesis = thesisService.updateThesisById(id, thesisDTO);
        return ResponseEntity.ok(thesis);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteThesis(@PathVariable Long id){
        try{
            thesisService.deleteThesisById(id);
            return ResponseEntity.ok("The Thesis has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Thesis>> fetchAll(){
        List<Thesis> theses= thesisService.findAllTheses();
        return ResponseEntity.ok(theses);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<Thesis> fetchById(@PathVariable long id) {
        Thesis thesis = thesisService.findThesisById(id)
                .orElseThrow(() -> new EntityNotFoundException("Thesis not found with id: " + id));
        return ResponseEntity.ok(thesis);
    }

    @GetMapping("/by-grade-range")
    public ResponseEntity<List<Thesis>> getThesesByGradeRange(
            @RequestParam String minGrade,
            @RequestParam String maxGrade,
            @RequestParam long teacherId) {
        List<Thesis> theses = thesisService.getThesesByGradeRange(minGrade, maxGrade, teacherId);
        return ResponseEntity.ok(theses);
    }
}
