package com.example.graduate.model;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "thesis")
@Entity
public class Thesis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "thesis_id")
    long id;

    @NotNull(message = "Name cannot be null")
    @Column(name = "name", nullable = false)
    String name;

    @NotNull(message = "Text cannot be null")
    @Column(name = "text", nullable = false)
    String text;

    @NotNull(message = "Date of uploading cannot be null")
    @Column(name = "date_uploaded", nullable = false)
    LocalDate dateUploaded;

    @NotNull(message = "Application cannot be null")
    @ManyToOne
    @JoinColumn(name = "application_id", nullable = false)
    @JsonBackReference
    Application application;

    @JsonIgnore
    @OneToMany(mappedBy = "thesis", cascade = CascadeType.ALL)
    @JsonManagedReference
    Set<Review> reviews;

    @OneToMany(mappedBy = "thesis", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("thesis-defending-reference") // Matching reference for Thesis
    Set<ThesisDefending> thesisDefendings;


}
