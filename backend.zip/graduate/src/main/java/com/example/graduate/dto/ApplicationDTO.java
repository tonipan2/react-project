package com.example.graduate.dto;

import com.example.graduate.model.AcceptanceType;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ApplicationDTO {
    long id;
    String theme;
    String aim;
    String tasks;
    String technologies;
    AcceptanceType acceptanceType;
    long studentId;
    long teacherId;

    public ApplicationDTO(Long id, String theme, String aim, String tasks, String technologies, AcceptanceType acceptanceType, Long studentId, Long teacherId) {
        this.id = id;
        this.theme = theme;
        this.aim = aim;
        this.tasks = tasks;
        this.technologies = technologies;
        this.acceptanceType = acceptanceType;
        this.studentId = studentId;
        this.teacherId = teacherId;
    }
}