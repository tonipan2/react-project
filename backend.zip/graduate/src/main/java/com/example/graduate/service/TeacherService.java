package com.example.graduate.service;

import com.example.graduate.dto.*;
import com.example.graduate.model.*;
import com.example.graduate.repository.*;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service

public class TeacherService {
    private final TeacherRepository teacherRepo;
    private final UserService userService;
    private final StudentService studentService;
    private final DepartmentService departmentService;
    private final DepartmentRepository departmentRepo;

    @Autowired
    public TeacherService(TeacherRepository teacherRepo, UserService userService, StudentService studentService, DepartmentService departmentService, DepartmentRepository departmentRepo) {
        this.teacherRepo = teacherRepo;
        this.userService = userService;
        this.studentService = studentService;
        this.departmentService = departmentService;
        this.departmentRepo = departmentRepo;
    }
    /**
     * Saves a new {@link Teacher} based on the provided {@link TeacherDTO}.
     *
     * @param teacherDTO the data transfer object representing the new teacher.
     */

    public Teacher saveTeacher(TeacherDTO teacherDTO) {
        User user = userService.findUserById(teacherDTO.getUserId());
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        validateRoleIsTeacher(user);

        Teacher teacherToSave = new Teacher();

        teacherToSave.setUser(user);
        teacherToSave.setFacultyNumber(teacherDTO.getFacultyNumber());
        teacherToSave.setPosition(teacherDTO.getPosition());

        Set<Department> departments = new HashSet<>(departmentRepo.findAllById(teacherDTO.getDepartmentIds()));
        teacherToSave.setDepartments(departments);

        for (Department department : departments) {
            department.getTeachers().add(teacherToSave);  // Update the inverse relationship
        }

        return teacherRepo.save(teacherToSave);
    }




    /**
     * Updates an existing {@link Teacher} identified by its ID.
     *
     * @param teacherId      the ID of the teacher to update.
     * @param updatedTeacher the updated data transfer object for the teacher.
     */
    public Teacher updateTeacherById(long teacherId, TeacherDTO updatedTeacher) {
        // Find and validate the new user
        User newUser = userService.findUserById(updatedTeacher.getUserId());
        validateRoleIsTeacher(newUser);

        Teacher teacherToUpdate = findTeacherById(teacherId);
        teacherToUpdate.setUser(newUser);

        teacherToUpdate.setFacultyNumber(updatedTeacher.getFacultyNumber());
        teacherToUpdate.setPosition(updatedTeacher.getPosition());

        // Update departments (handle null or empty lists)
        if (updatedTeacher.getDepartmentIds() != null && !updatedTeacher.getDepartmentIds().isEmpty()) {
            Set<Department> departments = new HashSet<>(departmentRepo.findAllById(updatedTeacher.getDepartmentIds()));
            teacherToUpdate.setDepartments(departments);

            for(Department department : departments){
                department.getTeachers().add(teacherToUpdate);
            }
        } else {
            teacherToUpdate.getDepartments().clear();  // If null, clear the association
        }
        return teacherRepo.save(teacherToUpdate);
    }




    /**
     * Validates that the account role is "teacher".
     *
     * @param user the account to validate.
     * @throws IllegalArgumentException if the account role is not "teacher".
     */
    public void validateRoleIsTeacher(User user) {
        // had to add the casting after the 'many to many' relationship change for acc and accRole
        boolean isTeacher = user.getAuthorities().stream()
                .anyMatch(role -> role.getAuthority().equals("ROLE_TEACHER"));

        if (!isTeacher) {
            throw new IllegalArgumentException("Role must be teacher to assign account to a teacher");
        }
    }


    /**
     * Deletes an existing {@link Teacher} identified by its ID.
     *
     * @param id the ID of the teacher to delete.
     * @throws EntityNotFoundException if the teacher with the specified ID is not found.
     */
    public void deleteTeacherById(long id) {
        if (!doesTeacherExist(id)) {
            throw new EntityNotFoundException("Teacher not found with id: " + id);
        }

        Teacher teacherToDelete = findTeacherById(id);

        // Remove this teacher from all associated departments
        for (Department department : teacherToDelete.getDepartments()){
            department.getTeachers().remove(teacherToDelete);
            departmentRepo.save(department);
        }

        // Now delete the teacher
        teacherRepo.deleteById(id);
    }


    /**
     * Retrieves an existing {@link Teacher} identified by its ID.
     *
     * @param id the ID of the teacher to retrieve.
     * @return the teacher with the specified ID.
     * @throws EntityNotFoundException if the teacher with the specified ID is not found.
     */
    public Teacher findTeacherById(long id) {
        return teacherRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Teacher not found with id: " + id));
    }

    /**
     * Retrieves an existing {@link Teacher} identified by the associated user's ID.
     *
     * @param username the username of the user associated with the teacher.
     * @return the teacher associated with the given username.
     * @throws EntityNotFoundException if no teacher is found for the given user ID or if the user role is not "teacher".
     */
    public Teacher findTeacherByUsername(String username) {
        User user = userService.findUserByUsername(username);
        validateRoleIsTeacher(user);

        return teacherRepo.findByUser(user)
                .orElseThrow(() -> new EntityNotFoundException("Teacher not found for username: " + username));
    }


    /**
     * Retrieves all existing {@link Teacher} entities.
     *
     * @return a list of all teachers.
     */
    public List<Teacher> findAllTeachers() {
        return teacherRepo.findAll();
    }

    public Set<Teacher> findAllByDepartment(long teacherId){
            Optional<Teacher> teacherOptional = teacherRepo.findById(teacherId);
            if (teacherOptional.isEmpty()) {
                throw new EntityNotFoundException("Teacher with ID " + teacherId + " not found.");
            }

            Teacher teacher = teacherOptional.get();

            Set<Department> teacherDepartments = teacher.getDepartments();

            if (teacherDepartments.isEmpty()) {
                throw new IllegalStateException("Teacher with ID " + teacherId + " is not associated with any department.");
            }

            return teacherRepo.findAllByDepartments(teacherDepartments);
    }
    /**
     * Checks if a teacher with the specified ID exists.
     *
     * @param id the ID of the teacher to check.
     * @return {@code true} if the teacher exists, {@code false} otherwise.
     */
    public boolean doesTeacherExist(long id) {
        return teacherRepo.existsById(id);
    }

    public List<Application> findTeacherApplications(long teacherId) {

        Optional<Teacher> teacherOptional = teacherRepo.findById(teacherId);
        if (teacherOptional.isEmpty()) {
            throw new EntityNotFoundException("Teacher with ID " + teacherId + " not found.");
        }

        Teacher teacher = teacherOptional.get();

        Set<Department> teacherDepartments = teacher.getDepartments();

        if (teacherDepartments.isEmpty()) {
            throw new IllegalStateException("Teacher with ID " + teacherId + " is not associated with any department.");
        }

        return teacherRepo.findApplicationsByDepartments(teacherDepartments);
    }

    public List<Defending> getDefendingsForTeacher(Long teacherId) {
        return teacherRepo.findDefendingsByTeacher(teacherId);
    }

}
