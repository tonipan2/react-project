package com.example.graduate.repository;
import com.example.graduate.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    boolean existsById(long reviewId);
    Review findByThesisId(Long thesisId);

    @Query("SELECT COUNT(DISTINCT a.student.id) " +
            "FROM Review r " +
            "JOIN r.thesis t " +
            "JOIN t.application a " +
            "WHERE r.conclusion = false")
    long countStudentsWithNegativeReviews();
}
