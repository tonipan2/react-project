package com.example.graduate.dto;

import com.example.graduate.model.Position;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TeacherDTO {
    long userId;
    long id;
    String facultyNumber;
    Position position;
    Set<Long> departmentIds;
    public TeacherDTO(long id, long userId, Set<Long> departmentIds, Object o, Position position) {
        this.id = id;
        this.userId = userId;
        this.departmentIds = departmentIds;
        this.position = position;
    }

}