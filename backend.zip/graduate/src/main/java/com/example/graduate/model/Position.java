package com.example.graduate.model;

public enum Position {
    ASSISTANT, HEAD_ASSISTANT, PROFESSOR, DOCTOR
}
