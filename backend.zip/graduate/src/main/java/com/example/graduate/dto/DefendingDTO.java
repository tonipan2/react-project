package com.example.graduate.dto;

import com.example.graduate.model.Teacher;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DefendingDTO {
    long id;
    LocalDate dateDefending;
    Set<Long> teacherIds;
}