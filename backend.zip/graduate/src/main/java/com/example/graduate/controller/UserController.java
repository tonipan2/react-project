package com.example.graduate.controller;

import com.example.graduate.dto.UserDTO;
import com.example.graduate.model.User;
import com.example.graduate.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/user")
public class UserController {
    private final UserService userService;

    @PostMapping("/add")
    public ResponseEntity<?> addUser(@RequestBody UserDTO userDTO) {
        try {
            userService.saveUser(userDTO);
            return ResponseEntity.ok("User added successfully");
        } catch (Exception e) {
            // Log the exception and return a 500 error response
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<User> patchAccount(@PathVariable Long id, @RequestBody UserDTO userDTO){
        User user = userService.updateUserById(id, userDTO);
        return ResponseEntity.ok(user);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long id){
        try{
            userService.deleteUserById(id);
            return ResponseEntity.ok("The User has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<User>> fetchAll(){
        List<User> users = userService.findAllUsers();
        return ResponseEntity.ok(users);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<User> fetchById(@PathVariable long id){
        User user = userService.findUserById(id);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/fetchByUsername/{username}")
    public ResponseEntity<User> fetchByUsername(@PathVariable String username){
        User user = userService.findUserByUsername(username);
        return ResponseEntity.ok(user);
    }


    // Endpoint to find account by password and username
    @GetMapping("/fetchByPasswordAndUsername")
    public ResponseEntity<User> fetchByPasswordAndUsername(
            @RequestParam String username,
            @RequestParam String password) {

        User user = userService.findUserByUsernameAndPassword(username, password);
        return ResponseEntity.ok(user);
    }

}
