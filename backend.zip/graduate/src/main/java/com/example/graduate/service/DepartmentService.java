package com.example.graduate.service;

import com.example.graduate.dto.DepartmentDTO;
import com.example.graduate.model.Department;
import com.example.graduate.model.Student;
import com.example.graduate.model.Teacher;
import com.example.graduate.repository.DepartmentRepository;
import com.example.graduate.repository.StudentRepository;
import com.example.graduate.repository.TeacherRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service

public class DepartmentService {
    private final DepartmentRepository departmentRepo;


    @Autowired
    public DepartmentService(DepartmentRepository departmentRepo) {
        this.departmentRepo = departmentRepo;
    }
    /**
     * Saves a new {@link Department} based on the provided {@link DepartmentDTO}.
     *
     * @param departmentDTO the data transfer object representing the new department.
     */

    public Department saveDepartment(DepartmentDTO departmentDTO){
        Department departmentToSave = new Department();
        departmentToSave.setDepartmentName(departmentDTO.getDepartmentName());
        return departmentRepo.save(departmentToSave);
    }
    /**
     * Updates an existing {@link Department} identified by its ID.
     *
     * @param departmentId      the ID of the student to update.
     * @param updatedDepartment the updated data transfer object for the department.
     */
    public Department updateDepartmentById(long departmentId, DepartmentDTO updatedDepartment) {

        Department departmentToUpdate = findDepartmentById(departmentId)
                .orElseThrow(() -> new EntityNotFoundException("Department not found with id: " + departmentId));

        departmentToUpdate.setDepartmentName(updatedDepartment.getDepartmentName());

        return departmentRepo.save(departmentToUpdate);
    }

    /**
     * Deletes an existing {@link Department} identified by its ID.
     *
     * @param id the ID of the department to delete.
     * @throws EntityNotFoundException if the department with the specified ID is not found.
     */
    public void deleteDepartmentById(long id) {
        if (!doesDepartmentExist(id)){
            throw new EntityNotFoundException("Department not found with id: " + id);
        }
        departmentRepo.deleteById(id);
    }

    /**
     * Retrieves an existing {@link Department} identified by its ID.
     *
     * @param id the ID of the department to retrieve.
     * @return the department with the specified ID.
     * @throws EntityNotFoundException if the department with the specified ID is not found.
     */
    public Optional<Department> findDepartmentById(long id) {
        return Optional.ofNullable(departmentRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Department not found with id: " + id)));
    }

    /**
     * Retrieves all existing {@link Department} entities.
     *
     * @return a list of all department.
     */
    public List<Department> findAllDepartments() {
        return departmentRepo.findAll();
    }

    /**
     * Checks if a department with the specified ID exists.
     *
     * @param id the ID of the department to check.
     * @return {@code true} if the department exists, {@code false} otherwise.
     */
    public boolean doesDepartmentExist(long id) {
        return departmentRepo.existsById(id);
    }


}
