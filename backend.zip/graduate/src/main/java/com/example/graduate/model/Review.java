package com.example.graduate.model;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Table(name = "review")
@Entity
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "review_id")
    long id;

    @NotNull(message = "Text cannot be null")
    @Column(name = "text", nullable = false)
    String text;

    @NotNull(message = "Date of uploading cannot be null")
    @Column(name = "date_uploaded", nullable = false)
    LocalDate dateUploaded;

    @NotNull(message = "Conclusion cannot be null")
    @Column(name = "conclusion", nullable = false)
    Boolean conclusion;

    @NotNull(message = "Thesis cannot be null")
    @ManyToOne
    @JoinColumn (name = "thesis_id", nullable = false)
    @JsonBackReference
    Thesis thesis;

    @NotNull(message = "Teacher cannot be null")
    @ManyToOne
    @JoinColumn (name = "teacher", nullable = false)
    @JsonBackReference
    Teacher teacher;

}
