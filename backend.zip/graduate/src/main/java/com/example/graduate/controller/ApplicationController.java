package com.example.graduate.controller;

import com.example.graduate.dto.ApplicationDTO;
import com.example.graduate.model.Application;
import com.example.graduate.service.ApplicationService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/application")
public class ApplicationController {
    private final ApplicationService applicationService;
    @Autowired
    ApplicationController(ApplicationService applicationService){
        this.applicationService = applicationService;
    }

    @PostMapping("/add")
    public ResponseEntity<Application> postApplication(@RequestBody ApplicationDTO applicationDTO){
        Application application = applicationService.saveApplication(applicationDTO);
        return ResponseEntity.ok(application);
    }

    @PatchMapping("/edit/{id}")
    public ResponseEntity<Application> patchApplication(@PathVariable Long id, @RequestBody ApplicationDTO applicationDTO){
        Application application = applicationService.updateApplicationById(id, applicationDTO);
        return ResponseEntity.ok(application);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteApplication(@PathVariable Long id){
        try{
            applicationService.deleteApplicationById(id);
            return ResponseEntity.ok("The Application has been deleted");
        }catch (EntityNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/fetch/all")
    public ResponseEntity<List<Application>> fetchAll(){
        List<Application> applications= applicationService.findAllApplications();
        return ResponseEntity.ok(applications);
    }
    @GetMapping("/fetch/{id}")
    public ResponseEntity<Application> fetchById(@PathVariable long id) {
        Application application = applicationService.findApplicationById(id)
                .orElseThrow(() -> new EntityNotFoundException("Application not found with id: " + id));
        return ResponseEntity.ok(application);
    }

}
